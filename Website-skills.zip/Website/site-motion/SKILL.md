---
name: site-motion
description: >
  Step 5 of 8 in the Motion Site Engine Pipeline. Takes site_map.md and
  design_system.md and specifies the motion layer: the timing and easing
  tokens, a per-section scroll choreography, the interactive artefact's full
  interaction spec, the motion performance budget, and a complete
  prefers-reduced-motion fallback for every single effect. Motion that cannot
  be disabled does not ship. Saves as motion_spec.md.
---

# Site Motion

Motion is not decoration applied after the layout.
It is the explanation of how the page's parts relate, played in time.
Every effect earns its place by making something clearer, or it goes.
And every effect has a fallback, because a site that makes someone
nauseous is not a high-class site.
Save as `motion_spec.md`.

---

## The Motion Rules

```
THE FOUR LAWS:

  1. MOTION EXPLAINS, OR IT GOES.
     Before specifying any effect, write the sentence "this motion makes
     ___ clearer." If the sentence cannot be finished, cut the effect.
     Decoration is what separates a motion site from an expensive-feeling
     one.

  2. EVERY EFFECT HAS A REDUCED-MOTION FALLBACK.
     Not "animations off" globally — a specified end state per effect.
     WCAG SC 2.3.3 Animation from Interactions requires that motion
     animation triggered by interaction can be disabled unless it is
     essential to the functionality or information conveyed, and names
     scroll parallax and click-triggered animation explicitly. The
     sufficient technique is the prefers-reduced-motion media query
     (C39 in CSS, SCR40 in JavaScript).

  3. PAGE-INITIATED MOTION IS A LEVEL A OBLIGATION.
     2.3.3 covers motion the USER triggers and is Level AAA. Motion the
     PAGE starts — an autoplaying hero loop, a marquee, a carousel — falls
     under SC 2.2.2 Pause, Stop, Hide, which is Level A. Anything moving
     for more than five seconds that the page started needs a pause
     control. Almost every motion site has an autoplaying hero; almost none
     has the control. Specify it.

  4. MOTION NEVER BLOCKS CONTENT.
     Text revealed on scroll must be in the DOM and readable if the
     animation never fires. Never gate content behind an IntersectionObserver
     with opacity:0 as the authored default — a failed script leaves a blank
     page.

THE RULE:
  Never animate a property other than transform, opacity or filter without
  recording why.
  Never exceed the motion budget in Step 4 below.
  Never ship an effect with no fallback row in the matrix.
  Never let the hero's animation be the LCP element.
```

---

## Step 1 — Timing and Easing Tokens

```
FOUR DURATIONS, THREE EASINGS. EVERYTHING USES THEM.

    --dur-instant  100ms   state flips, checkbox, toggle
    --dur-fast     200ms   hover, focus, small reveals
    --dur-base     320ms   cards, accordions, menu open
    --dur-slow     600ms   section reveals, hero staging
  □ Nothing over 600ms except a deliberate scroll-linked sequence, which
    is driven by scroll position rather than a duration
  □ Hover must be ≤200ms. A slow hover feels broken, not elegant.

    --ease-out    cubic-bezier(0.16, 1, 0.3, 1)      entering, revealing
    --ease-in-out cubic-bezier(0.65, 0, 0.35, 1)     moving between states
    --ease-spring cubic-bezier(0.34, 1.56, 0.64, 1)  playful overshoot

  □ Entering elements use ease-out — fast start, soft landing
  □ Leaving elements are faster than entering: exit at --dur-fast
  □ Spring only at motion tier 3-4, and never on a form control

  THE STAGGER CONSTANT:
    --stagger 60ms between siblings in a group
  □ 40-80ms reads as one gesture; over 120ms reads as a queue
  □ Cap any stagger group at 6 items — beyond that the last item arrives
    too late to feel related

  DISTANCE DISCIPLINE:
  □ Reveal translations: 12-24px. Never 100px — large travel is what
    triggers vestibular discomfort.
  □ Scale: 0.96 to 1.0. Never from 0.
  □ No effect moves an element further than its own height.
```

---

## Step 2 — The Motion Inventory

```
LIST EVERY EFFECT ON THE SITE. ONE ROW EACH. NOTHING UNLISTED SHIPS.

  | # | Section | Effect | Trigger | Property | Duration | Makes clearer |
  |---|---------|--------|---------|----------|----------|---------------|
  | 1 | hero    | staged reveal | load | opacity, translateY | 600ms | the reading order |

  THE EFFECT VOCABULARY — by motion tier from Round 7:

  TIER 1 RESTRAINED
    □ Fade-and-rise on section entry (opacity 0→1, translateY 16px→0)
    □ Hover lift on cards (translateY -2px, shadow-sm→shadow-md)
    □ Underline grow on inline links
    □ Button press (scale 0.98 on :active)
    □ Focus ring transition
    □ Smooth anchor scrolling

  TIER 2 CHOREOGRAPHED — adds:
    □ Staggered group reveals (--stagger between cards)
    □ Number count-up on stat entry
    □ Sticky section headers with a progress indicator
    □ Pinned section with content stepping through (the 01/02/03 pattern)
    □ Horizontal scroll gallery driven by vertical scroll
    □ Logo wall marquee (needs a 2.2.2 pause control)
    □ Hero loop video or sprite (needs a 2.2.2 pause control)
    □ Scroll-linked progress bar
    □ Parallax on a background layer — 0.1 to 0.3 factor only

  TIER 3 INTERACTIVE — adds:
    □ The interactive artefact (Step 3 below)
    □ Cursor-following highlight or spotlight
    □ Drag interactions
    □ Live toggles that change a visible output
    □ Magnetic buttons, tilt-on-hover cards
    □ Animated SVG draw-on

  TIER 4 SHOWPIECE — adds:
    □ WebGL / Three.js scene
    □ Shader-based transitions
    □ 3D model viewer
    □ Canvas particle fields
    □ Scroll-driven camera movement
    ⚠️ Every one of these still has to pass Step 7's performance gates.
       A 4MB WebGL bundle that blows LCP is not high-class, it is slow.
       Budget it in Step 4 below before committing.

  INVENTORY DISCIPLINE:
  □ Every row's "makes clearer" sentence is complete
  □ Count the effects: tier 1 ≤8 · tier 2 ≤16 · tier 3 ≤24 · tier 4 ≤30
  □ No section has more than 3 simultaneous effects
  □ Properties are transform / opacity / filter only, or the row records why
```

---

## Step 3 — The Interactive Artefact

```
THE ONE THING THE VISITOR OPERATES. SPEC IT COMPLETELY — IT IS A SMALL
PRODUCT, NOT AN ANIMATION.

  From the reference set, what these actually are:
    oryzo.ai      an encode/decode message toy, and a demo that
                  deliberately misreads a high five
    bops.bot      an approval card with Approve / Not now, a staff ID card,
                  simulated text, email and call exchanges
    exbcreative   a drag-to-pick gallery: "Pick up a piece to view the full
                  project" / "Drop to view project"
    oxylabs.io    a /Search ↔ /Scrape toggle driving a live demo panel
    marclou.com   a revenue chart with a "Show investments" filter, and a
                  GitHub contribution heatmap

  SPEC ALL NINE FIELDS:
    1. WHAT IT IS        [...]
    2. WHAT IT PROVES    the claim it substantiates without words
    3. INPUT             what the visitor does — click, drag, type, toggle
    4. OUTPUT            what visibly changes
    5. INITIAL STATE     what it looks like untouched, and whether it hints
    6. STATIC FALLBACK   what renders with no JS. Must be meaningful, not
                         an empty box. This is non-negotiable.
    7. KEYBOARD PATH     full operation without a mouse: which keys, what
                         focus order, what is announced
    8. ARIA              roles, labels, live-region announcements for the
                         output
    9. FAILURE STATE     what shows if the demo's backend is down

  THE HINT PROBLEM:
  An interactive element nobody realises is interactive is wasted. Both
  trylatent and oryzo print a literal scroll cue ("Scroll", "Scroll to
  continue"); exbcreative prints its drag instruction on the element. Say
  what to do. One short line, in the artefact.
    Hint copy: "[...]"

  □ Works on touch, not just hover — hover-only artefacts are dead on mobile
  □ Degrades to the static fallback below 640px if the interaction needs
    space it does not have
  □ Does not trap focus
  □ Does not autoplay sound, ever
```

---

## Step 4 — Scroll Choreography

```
WALK site_map.md SECTION BY SECTION. ASSIGN THE MOTION.

  | Section | Enter | Hold | Exit | Threshold | Fallback |
  |---------|-------|------|------|-----------|----------|
  | 1 hero | staged, 3 steps × 60ms | loop | — | load | all visible |
  | 2 proof | stagger logos | — | — | 0.2 | all visible |

  SCROLL MECHANICS:
  □ Reveal threshold 0.15-0.25 of the element in view — any later and the
    content appears after the reader has reached it
  □ Reveals fire ONCE. Re-animating on scroll-back is nauseating.
  □ IntersectionObserver, never a scroll event listener
  □ Pinned sections: state the pin duration in viewport heights (1.5-3vh
    max; longer and the visitor thinks the page has frozen)
  □ Every pinned section has a visible progress indicator
  □ No pinning below 1024px — on mobile it fights the native scroll

  THE HERO STAGE:
  3-4 steps, 60-80ms apart, 600ms total. Order: headline → subhead → CTAs
  → visual. The visual is last because it is the heaviest.
  □ The LCP element is NOT animated from opacity:0. Render it, then animate
    everything around it. This is the single most common way a beautiful
    hero fails LCP.

  THE MOTION PERFORMANCE BUDGET:
    Total JS for motion         ≤ 40KB gzipped (tier 1-2)
                                ≤ 120KB gzipped (tier 3)
                                ≤ 400KB gzipped (tier 4, lazy-loaded)
    Animation library           one, or none
    Elements animating at once  ≤ 12
    Frame budget                16.6ms — 60fps
    will-change                 only during an animation, removed after
    Composited properties only  transform, opacity, filter
  □ Tier 4 assets lazy-load after first paint and never block LCP
  □ Record the chosen library and its actual gzipped size
```

---

## Step 5 — The Reduced-Motion Matrix

```
ONE ROW PER EFFECT FROM THE STEP 2 INVENTORY. NO ROW MAY BE BLANK.

  | # | Effect | Reduced-motion behaviour |
  |---|--------|--------------------------|
  | 1 | hero staged reveal | all elements visible, no transform, no delay |
  | 2 | card hover lift | shadow change only, no translate |
  | 3 | stat count-up | final number rendered immediately |
  | 4 | pinned section | unpinned, sections stack and scroll normally |
  | 5 | parallax layer | static background |
  | 6 | logo marquee | static grid, wraps |
  | 7 | hero video loop | poster frame, play button |
  | 8 | drag gallery | tap-to-open, no drag |

  THE PRINCIPLE: reduced motion means the END STATE, INSTANTLY. It does not
  mean the content disappears. Every reveal's fallback is "visible".

  THE CSS SHAPE — author the static state, add motion inside the query:
```css
/* authored default: visible, no transform */
.reveal { opacity: 1; }

@media (prefers-reduced-motion: no-preference) {
  .reveal {
    opacity: 0;
    transform: translateY(16px);
    transition: opacity var(--dur-slow) var(--ease-out),
                transform var(--dur-slow) var(--ease-out);
  }
  .reveal.is-in { opacity: 1; transform: none; }
}
```
  This ordering matters: the no-preference query wraps the MOTION, so the
  authored default is the accessible state. Written the other way round, a
  reduced-motion user gets opacity:0 content if the override misses.

  THE JS SHAPE:
```js
const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
if (reduce.matches) { applyEndState(); } else { animate(); }
reduce.addEventListener('change', e => {
  if (e.matches) { killAnimations(); applyEndState(); }
});
```
  □ The change listener matters — someone can flip the OS setting mid-visit
  □ GSAP, Framer Motion and Lottie all need this check explicitly; none of
    them honours the preference by default

  THE PAUSE CONTROLS (SC 2.2.2, Level A — page-initiated motion):
  | Moving element | Duration | Control |
  |----------------|----------|---------|
  | hero video loop | continuous | visible pause button |
  | logo marquee | continuous | pause on hover + focus, and a button |
  □ Anything page-initiated running over 5 seconds needs a control
  □ "Pause on hover" alone is not sufficient — keyboard users need it too

  MATRIX COMPLETENESS:
  Effects in inventory: [N] · Rows in matrix: [N] · Must be equal.
  Page-initiated effects: [N] · With pause controls: [N] · Must be equal.
```

---

## Output File: motion_spec.md

```markdown
# Motion Spec
Pipeline step: 5 of 8
Date: [date]
Reads: site_brief.md, site_map.md, design_system.md

---

## Tier
Tier [N] — [name], from Round 7
Signature moment: [...]

---

## Tokens
```css
--dur-instant: 100ms; --dur-fast: 200ms;
--dur-base: 320ms; --dur-slow: 600ms;
--ease-out: cubic-bezier(0.16, 1, 0.3, 1);
--ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
--stagger: 60ms;
```

---

## Motion Inventory
| # | Section | Effect | Trigger | Property | Duration | Makes clearer |
|---|---------|--------|---------|----------|----------|---------------|

Effects: [N] / budget [N]
Non-composited properties: [N] (each with a reason)
Max simultaneous in one section: [N] (≤3)

---

## Interactive Artefact
1 What: [...]
2 Proves: [...]
3 Input: [...]
4 Output: [...]
5 Initial state: [...]
6 Static fallback: [...]
7 Keyboard path: [...]
8 ARIA: [...]
9 Failure state: [...]
Hint copy: "[...]"
Touch: [...] · Below 640px: [...]

---

## Scroll Choreography
| Section | Enter | Hold | Exit | Threshold | Fallback |
|---------|-------|------|------|-----------|----------|

Pinned sections: [N] · pin durations: [list] · progress indicators: [N]/[N]
LCP element animated from opacity:0: [NO — required]

---

## Performance Budget
Library: [name, version] · Gzipped: [N]KB / budget [N]KB
Elements animating at once: [N] (≤12)
Tier 4 assets lazy-loaded: [yes / n-a]

---

## Reduced-Motion Matrix
| # | Effect | Reduced-motion behaviour |
|---|--------|--------------------------|

Inventory: [N] · Matrix rows: [N] · Equal: [PASS/FAIL]

## Pause Controls (SC 2.2.2)
| Moving element | Duration | Control |
|----------------|----------|---------|

Page-initiated: [N] · Controlled: [N] · Equal: [PASS/FAIL]

---

## Pipeline Status
Step 1 ✅ site-brief     → site_brief.md
Step 2 ✅ site-architect → site_map.md
Step 3 ✅ site-copy      → site_copy.md
Step 4 ✅ site-design    → design_system.md
Step 5 ✅ site-motion    → motion_spec.md
Step 6 ⬜ site-build     → build_log.md
Step 7 ⬜ site-audit     → quality_report.md
Step 8 ⬜ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `motion_spec.md`, present this EXACTLY:

```
✅ Motion spec complete. Saved to motion_spec.md.

📋 Summary:
- Tier         : [N] — [name]
- Effects       : [N] (budget [N])
- Pinned        : [N] sections
- Artefact      : [the thing] — [input] → [output]
- Library       : [name], [N]KB gzipped (budget [N]KB)
- Signature     : [the screenshot moment]

Accessibility:
  Reduced-motion matrix : [N] effects / [N] rows [PASS/FAIL]
  Pause controls (2.2.2): [N] page-initiated / [N] controlled [PASS/FAIL]
  Static fallback for artefact : [specified / MISSING]
  Keyboard path for artefact   : [specified / MISSING]
  LCP element not animated     : [PASS/FAIL]

Every effect's "makes clearer" sentence: [N]/[N] complete
[IF any incomplete] ⚠️ These effects have no justification and have been
cut: [list]

[IF matrix incomplete] 🛑 [N] effects have no reduced-motion fallback.
Motion that cannot be disabled does not ship — specify them or cut them.

[IF tier 4] ⚠️ Tier 4 budget is [N]KB. This still has to pass LCP ≤2.5s in
Step 7. Assets are lazy-loaded after first paint; if the gate fails there,
the scene gets cut, not the gate.

👉 Review motion_spec.md. You can:
  - Approve → say "approved" or "build it"
  - Change tier → say "tier [N]"
  - Cut an effect → say "drop effect [N]"
  - Change the artefact → say "make the demo [X]"
  - More restraint → say "halve the effects"
  - Change the library → say "use [library]"

⏸️ Waiting for approval before Build runs.
```

**NEVER** proceed automatically.

**NEVER** ship an effect with no row in the reduced-motion matrix.

**NEVER** leave page-initiated motion without a pause control.

Approval keywords: `approved`, `build it`, `build`,
`proceed`, `next`, `go`, `looks good`, `motion approved`
