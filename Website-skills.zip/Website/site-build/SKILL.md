---
name: site-build
description: >
  Step 6 of 8 in the Motion Site Engine Pipeline. Takes site_copy.md,
  design_system.md and motion_spec.md and writes the actual multi-page site:
  file structure, semantic HTML per page, tokens.css plus component CSS, the
  motion layer, the interactive artefact, forms, SEO head tags and the asset
  pipeline. Content first, then style, then motion — in that order, so the
  site works at every stage. Saves as build_log.md.
---

# Site Build

Build it in three passes, in this order:
content that works with no CSS, style that works with no JS,
motion that works on top of both.
Built the other way round, every failure is total.
Built this way, every failure is cosmetic.
Save as `build_log.md`.

---

## The Build Rules

```
LOAD BEFORE BUILDING:
  site_copy.md      — every word. Nothing is written here.
  design_system.md  — tokens.css, verbatim. No new values.
  motion_spec.md    — the inventory and the reduced-motion matrix.
  site_map.md       — section order per page.

THE THREE PASSES — complete each across the whole site before the next:
  PASS 1 CONTENT   semantic HTML, every page, real copy, no CSS.
                   Read it with styles disabled. It must make sense.
  PASS 2 STYLE     tokens, layout, components, responsive. No JS.
                   Every page usable with JavaScript off.
  PASS 3 MOTION    the motion layer, progressively enhanced on top.

  Why this order: a site built style-first hides content failures behind
  layout, and a site built motion-first hides both. Each pass is
  independently shippable.

THE RULE:
  Never write a word that is not in site_copy.md.
  Never write a hex value or a px spacing outside tokens.css.
  Never let a section's content depend on JavaScript to be readable.
  Never use a div where a semantic element exists.
  Never ship a TODO, a console.log, or a commented-out block.
```

---

## Step 1 — File Structure

```
FOR A MULTI-PAGE STATIC SITE:

  /
  ├── index.html
  ├── features.html        (or /features/index.html for clean URLs)
  ├── pricing.html
  ├── about.html
  ├── docs.html
  ├── contact.html
  ├── blog.html            (shell + one example post)
  ├── 404.html
  ├── thanks.html
  ├── privacy.html · terms.html · cookies.html
  ├── css/
  │   ├── tokens.css       from Step 4, verbatim
  │   ├── base.css         reset, elements, typography
  │   ├── layout.css       container, grid, section templates
  │   ├── components.css   buttons, cards, nav, forms, accordion
  │   └── motion.css       all motion, inside no-preference queries
  ├── js/
  │   ├── nav.js           mobile drawer, sticky
  │   ├── reveal.js        IntersectionObserver reveals
  │   ├── artefact.js      the interactive artefact
  │   └── forms.js         validation and states
  ├── assets/
  │   ├── img/             webp/avif + fallback, sized
  │   ├── video/           poster frames beside every video
  │   ├── fonts/           self-hosted, woff2, subset
  │   └── icons/           one sprite or inline SVG
  ├── favicon.svg · apple-touch-icon.png · site.webmanifest
  ├── robots.txt
  └── sitemap.xml

  SHARED MARKUP WITHOUT A BUILD STEP:
  The nav and footer repeat on every page. Three honest options:
  A  Duplicate the markup. Fine at ≤6 pages. Record that a nav change means
     editing N files.
  B  Inject with a small JS include. Costs a flash and hurts SEO slightly.
     Not recommended for nav.
  C  Use a static site generator (11ty, Astro). Correct at 7+ pages or if
     Round 6 said a non-developer must edit it.
  □ Pick by page count and Round 6's editability answer. Record the choice.

  CLEAN URLS:
  □ /pricing rather than /pricing.html — use directory-index files or the
    host's rewrite rules. Record which.
```

---

## Step 2 — Pass 1: Semantic HTML

```
PER PAGE, THE DOCUMENT SKELETON:

```html
<!DOCTYPE html>
<html lang="[lang]">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>[from site_copy.md]</title>
  <meta name="description" content="[from site_copy.md]">
  <link rel="canonical" href="[absolute URL]">
  <meta property="og:title" content="[...]">
  <meta property="og:description" content="[...]">
  <meta property="og:image" content="[absolute URL]">
  <meta property="og:type" content="website">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="preconnect" href="[font origin]" crossorigin>
  <link rel="preload" href="/assets/fonts/[main].woff2" as="font"
        type="font/woff2" crossorigin>
  <link rel="stylesheet" href="/css/tokens.css">
  <link rel="stylesheet" href="/css/base.css">
  <!-- ...layout, components, motion -->
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <script type="application/ld+json">[from site_copy.md]</script>
</head>
<body>
  <a href="#main" class="skip-link">Skip to main content</a>
  <header><nav aria-label="Main">…</nav></header>
  <main id="main">
    <section aria-labelledby="hero-h">
      <h1 id="hero-h">…</h1>
    </section>
    …
  </main>
  <footer>…</footer>
  <script src="/js/nav.js" defer></script>
</body>
</html>
```

  SEMANTIC REQUIREMENTS:
  □ ONE <h1> per page, and it is the hero headline
  □ Heading levels never skip — h1 → h2 → h3, no h1 → h3
  □ <section> with aria-labelledby pointing at its own heading
  □ <nav aria-label> on every nav (main, footer, breadcrumb)
  □ <button> for actions, <a> for navigation. Never a div with onclick.
  □ <ul>/<li> for every list, including card grids and logo walls
  □ <figure>/<figcaption> where an image has a caption
  □ <details>/<summary> for the FAQ accordion — free keyboard support,
    works with no JS
  □ <table> for the pricing comparison, with <th scope>
  □ <form> with real labels, autocomplete attributes and inputmode
  □ Skip link first in the DOM, visible on focus

  IMAGES:
  □ width and height on every <img> — this is the main CLS defence
  □ loading="lazy" on everything below the fold; NOT on the LCP image
  □ fetchpriority="high" on the LCP image
  □ <picture> with avif → webp → jpg
  □ alt text from site_copy.md's table, verbatim
  □ Videos: poster attribute always, preload="metadata", muted+playsinline
    if autoplaying, plus the pause control from the motion spec

  PASS 1 ACCEPTANCE:
  □ Disable CSS entirely. Every page reads top to bottom in a sensible
    order, every link labelled, every image described.
  □ Tab through. Focus order matches reading order.
  □ No layout, no colour, no motion — and the site still works.
```

---

## Step 3 — Pass 2: Style

```
CSS LOAD ORDER IS THE CASCADE. KEEP IT:
  tokens → base → layout → components → motion

  BASE:
  □ box-sizing: border-box on everything
  □ Sensible reset — margins off, img display:block, max-width:100%
  □ :focus-visible ring from the design system, on everything interactive
  □ scroll-behavior: smooth, inside a no-preference query
  □ Body: --font-body, --text-base, --leading-normal, --text, --bg

  LAYOUT:
  □ .container → max-width --container, padding-inline --gutter, mx auto
  □ .prose → max-width --container-text
  □ Section templates from design_system.md, one class each
  □ Background alternation applied per the recorded assignment
  □ Grid with minmax/auto-fit so cards reflow without breakpoint spam

  COMPONENTS:
  □ One block per component, all seven states
  □ Min touch target 44×44px on every control
  □ No fixed heights on anything containing text
  □ Hover effects wrapped in @media (hover: hover) so touch devices do not
    get stuck in a hover state

  RESPONSIVE:
  □ Mobile first — base styles are the small screen, media queries add up
  □ Test 320 / 390 / 768 / 1024 / 1440 / 1920
  □ Nav collapses to the drawer at the recorded breakpoint
  □ Pricing table scrolls horizontally with a visible affordance
  □ No horizontal overflow at any width — check with
    `document.documentElement.scrollWidth > window.innerWidth`

  DARK MODE if specified:
  □ prefers-color-scheme default plus [data-theme] override
  □ Toggle persists to localStorage, wrapped in try/catch
  □ Set the theme before first paint to avoid a flash — a tiny inline
    script in <head> is the correct exception to "no inline JS"

  PASS 2 ACCEPTANCE:
  □ Disable JavaScript entirely. Every page is fully usable: nav reachable
    (details/summary or a CSS-only drawer), FAQ expandable, forms
    submittable, artefact showing its static fallback.
  □ Every token used; no raw values anywhere outside tokens.css
```

---

## Step 4 — Pass 3: Motion

```
motion.css CARRIES EVERY EFFECT. THE AUTHORED DEFAULT IS THE END STATE.

```css
/* default: the accessible end state */
.reveal { opacity: 1; transform: none; }

@media (prefers-reduced-motion: no-preference) {
  .reveal {
    opacity: 0;
    transform: translateY(16px);
    transition: opacity var(--dur-slow) var(--ease-out),
                transform var(--dur-slow) var(--ease-out);
  }
  .reveal.is-in { opacity: 1; transform: none; }
  .reveal:nth-child(2) { transition-delay: var(--stagger); }
}
```

  reveal.js:
```js
const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
if (!reduce.matches && 'IntersectionObserver' in window) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.2, rootMargin: '0px 0px -10% 0px' });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
}
reduce.addEventListener('change', e => {
  if (e.matches) document.querySelectorAll('.reveal').forEach(el => el.classList.add('is-in'));
});
```
  □ unobserve after firing — reveals happen once
  □ No scroll event listeners anywhere
  □ will-change added on animation start, removed on finish
  □ Every effect in the inventory implemented; nothing extra added

  THE INTERACTIVE ARTEFACT:
  □ Build the static fallback FIRST, in HTML. Enhance it with JS.
  □ Implement the keyboard path from the motion spec exactly
  □ ARIA roles and the live region for output announcements
  □ The hint copy rendered in the markup
  □ Failure state handled — if a fetch fails, show the fallback, not a
    broken box
  □ Below 640px, degrade as specified

  PAUSE CONTROLS:
  □ Every page-initiated animation has its control, keyboard-reachable
  □ Hero video: pause button, labelled, state announced

  PASS 3 ACCEPTANCE:
  □ OS reduced-motion on → every effect matches its matrix row
  □ Flip the OS setting mid-page → running animations stop
  □ Throttle to 4× CPU → page still usable
  □ No effect fires twice on scroll-back
```

---

## Step 5 — Forms and Integrations

```
EVERY FORM, FULLY BUILT — all six states from site_copy.md.

  □ Real <label for> on every field, visible
  □ type and inputmode correct (email, tel, numeric)
  □ autocomplete attributes (email, name, organization)
  □ required plus aria-required
  □ Client validation that does not block submit on first blur
  □ Error messages in an aria-live="polite" region, tied by aria-describedby
  □ Submit disabled + loading label while in flight
  □ Success state replaces the form or redirects to /thanks
  □ Honeypot or timing check for spam. Never a CAPTCHA the pipeline
    cannot itself pass — and never one on a newsletter field.

  INTEGRATIONS from Round 6 — wire or stub each, and say which:
  □ Email capture  → endpoint, or a documented stub
  □ Analytics      → the snippet, cookie-consent-gated if required
  □ Payments       → link out to the provider's hosted checkout. Never
                     collect card details in this site's own fields.
  □ Booking        → embed or link
  □ Auth           → link to the app, not implemented here

  ⚠️ A marketing site never handles card numbers, passwords or bank
  details in its own inputs. Link to the provider's hosted page.
```

---

## Step 6 — Assets and Head

```
  IMAGES:
  □ Every image exported at 1× and 2× for its real display size
  □ avif + webp + fallback via <picture>
  □ Compress: photos ~80% quality, flat graphics as SVG
  □ No image over 200KB without a recorded reason
  □ The LCP image preloaded in <head>

  FONTS:
  □ Self-hosted woff2, subset to the characters actually used
  □ font-display: swap
  □ Preload only the one or two faces above the fold
  □ A metrics-matched fallback to limit layout shift on swap

  ICONS:
  □ Inline SVG for the few in critical markup; a sprite for the rest
  □ aria-hidden="true" on decorative icons; a <title> on meaningful ones
  □ No icon font

  FAVICON AND MANIFEST:
  □ favicon.svg + apple-touch-icon.png (180×180) + site.webmanifest
  □ theme-color matching --bg, per colour scheme

  robots.txt and sitemap.xml:
  □ sitemap lists every real page, absolute URLs, no 404s
  □ robots.txt points at the sitemap; nothing blocked that should be indexed
```

---

## Output File: build_log.md

```markdown
# Build Log
Pipeline step: 6 of 8
Date: [date]
Reads: site_copy.md, design_system.md, motion_spec.md, site_map.md

---

## Structure
Shared-markup strategy: [A duplicate / B inject / C generator] — [why]
Clean URLs: [how]
Files: [N] HTML · [N] CSS · [N] JS · [N] assets

| Page | File | Sections | Words | Status |
|------|------|----------|-------|--------|

---

## Pass 1 — Content
□ One h1 per page: [N]/[N]
□ No skipped heading levels: [PASS/FAIL]
□ Semantic elements used: [list]
□ All images have width/height + alt: [N]/[N]
□ CSS-disabled read-through: [PASS/FAIL]
□ Focus order matches reading order: [PASS/FAIL]

## Pass 2 — Style
□ Raw values outside tokens.css: [N] (must be 0)
□ All 7 states per component: [N]/[N]
□ Min target 44px: [PASS/FAIL]
□ Horizontal overflow at 320-1920: [NONE / list]
□ JS-disabled usability: [PASS/FAIL]
□ Dark mode: [implemented / n-a] · flash prevented: [yes]

## Pass 3 — Motion
□ Effects implemented: [N]/[N] from inventory
□ Extra effects added: [N] (must be 0)
□ Reduced-motion verified per matrix: [N]/[N]
□ Mid-page preference flip handled: [PASS/FAIL]
□ Pause controls built: [N]/[N]
□ Scroll listeners: [N] (must be 0)

## Interactive Artefact
Static fallback: [works / FAIL] · Keyboard: [works / FAIL]
ARIA + live region: [done] · Failure state: [done]
Below 640px: [behaviour]

## Forms
| Form | Fields | States built | Endpoint |
|------|--------|--------------|----------|

Integrations: [wired / stubbed, each]

## Assets
Images: [N], largest [N]KB · Fonts: [N] faces, [N]KB
Total page weight (home): [N]KB · JS: [N]KB gzipped

## Outstanding
TODOs: [N] (must be 0) · console.log: [N] (must be 0)
[ASSET NEEDED] unresolved: [list or none]

---

## Pipeline Status
Step 1 ✅ site-brief     → site_brief.md
Step 2 ✅ site-architect → site_map.md
Step 3 ✅ site-copy      → site_copy.md
Step 4 ✅ site-design    → design_system.md
Step 5 ✅ site-motion    → motion_spec.md
Step 6 ✅ site-build     → build_log.md
Step 7 ⬜ site-audit     → quality_report.md
Step 8 ⬜ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `build_log.md`, present this EXACTLY:

```
✅ Build complete. Saved to build_log.md.

📋 Summary:
- Pages built : [N]
- Files       : [N] HTML · [N] CSS · [N] JS · [N] assets
- Home weight : [N]KB ([N]KB JS gzipped)
- Effects     : [N]/[N] from the motion inventory
- Artefact    : built, with static fallback and keyboard path

Three-pass acceptance:
  Pass 1 — works with CSS disabled : [PASS/FAIL]
  Pass 2 — works with JS disabled  : [PASS/FAIL]
  Pass 3 — reduced motion verified : [N]/[N] effects

Hygiene:
  Raw values outside tokens : [N] (must be 0)
  Extra effects not in spec : [N] (must be 0)
  Scroll event listeners    : [N] (must be 0)
  TODOs / console.log       : [N] / [N] (must be 0)
  Horizontal overflow       : [none / list]

[IF any FAIL] 🛑 [N] acceptance failures: [list]. These are structural, not
cosmetic — fix before the audit.

[IF ASSET NEEDED] ⚠️ [N] assets still missing: [list]. Placeholders are in
place and flagged; the audit will fail until they are real.

👉 Review build_log.md. You can:
  - Approve → say "approved" or "audit it"
  - Fix a page → say "rebuild [page]"
  - Change the structure → say "use [generator] instead"
  - Drop an effect → say "remove effect [N]"
  - See it → say "show me the home page"

⏸️ Waiting for approval before Audit runs.
```

**NEVER** proceed automatically.

**NEVER** pass a build where content depends on JavaScript to be readable.

Approval keywords: `approved`, `audit it`, `audit`,
`proceed`, `next`, `go`, `looks good`, `build approved`
