# Motion Site Engine Skills

A reusable eight-step pipeline for building high-craft, motion-heavy,
multi-page websites — built on the same architecture as
`paper-engine-skills`, `Academic` and `LinkedIn`: each step is a skill, each
writes one output file, and each ends in a mandatory review gate that waits
for approval before the next step runs.

It starts by interrogating you. That is the point.

---

## The Pipeline

| # | Skill | Output | Does |
|---|-------|--------|------|
| 1 | `site-brief` | `site_brief.md` | **The grill.** Seven rounds of questions. Refuses to proceed on thin answers. |
| 2 | `site-architect` | `site_map.md` | IA, section order per page, conversion spine, nav, where the interactive artefact goes |
| 3 | `site-copy` | `site_copy.md` | Every word — including microcopy, form states, 404, meta and alt text |
| 4 | `site-design` | `design_system.md` | Tokens, type scale, contrast-verified colour, components, `tokens.css` |
| 5 | `site-motion` | `motion_spec.md` | Motion inventory, scroll choreography, the artefact spec, reduced-motion matrix |
| 6 | `site-build` | `build_log.md` | The site, in three passes: content → style → motion |
| 7 | `site-audit` | `quality_report.md` | Eight checks: performance, a11y, motion safety, responsive, content, SEO, robustness, conversion |
| 8 | `site-ship` | `publish_log.md` | Publish, domain, analytics, baseline, handover doc, archive |

Start with step 1. Say `approved` at each gate to advance.

---

## Why Step 1 Is The Whole Thing

Every generic website was built from a generic brief. A site built on "a
modern site for my AI product" can only be generic, because every decision
downstream has to be guessed.

So `site-brief` asks, across seven rounds:

1. **The product** — what it is, what it replaces, the one thing it does better
2. **The visitor** — who lands, from where, and the objection they arrive with
3. **The job** — the one primary conversion, measurably defined
4. **The proof** — what you can *actually* claim, with permission recorded
5. **The taste** — three reference sites and a specific reason for each
6. **The constraints** — pages, hosting, editability, legal, integrations
7. **The motion appetite** — a tier from restrained to showpiece

Each round has a pass bar. Thin answers get one follow-up, then are recorded
as THIN. **Three or more THIN rounds and the pipeline stops** and names what's
missing, rather than guessing on your behalf.

Banned taste answers, each with its follow-up: "modern", "clean",
"professional", "fun", "premium". Round 2's traffic-source question is the one
most briefs skip — a visitor from a launch post, from a search for your
competitor, and from a DM each need a different hero.

---

## What Was Extracted From The Reference Sites

Twenty sites studied. The structural findings are encoded as hard rules.

**The section library (17 types)** — nav, hero, proof bar, capability,
interactive artefact, simulated output, numbered sequence, editorial break,
testimonials, case studies, trust stack, shipping feed, aggregate stats,
pricing, FAQ, closing CTA, footer.

**Five heading grammars** — pick one per page and hold it:

- **G1 noun, past-participle** — "Hosting, handled." "Payments, processed." (lovable.dev)
- **G2 numbered panel** — "01 Record" "02 Track" "03 Share" (trylatent.co)
- **G3 declarative claim** — "The whole web, one API call away." (oxylabs.io)
- **G4 negation** — "Hire a bot, not a chatbot." "Ops, not brunch." (bops.bot)
- **G5 playful absurd** — "isn't just a coaster." (oryzo.ai)

**The interactive artefact.** The single clearest difference between a good
site and a memorable one is one thing the visitor can operate that isn't a
form. oryzo has a message encoder; bops has an Approve/Not now card and
simulated transcripts; exbcreative has a drag-to-pick gallery; oxylabs has a
/Search↔/Scrape toggle driving a live panel; marclou has a revenue chart with
a filter. Step 5 specs one in nine fields, including its static fallback and
keyboard path.

**Simulated output beats feature description.** bops.bot is built almost
entirely from showing the product's output as UI — an approval card, a "Done
today" feed, a staff ID card — rather than describing what it does.

**Numbers are never round.** 177M+ IPs. 195 locations. 51,492 subscribers.
$1,192,765 in 12 months. 1.2 million projects weekly. A round number reads as
an estimate, and the copy step enforces specificity.

---

## The Gates That Don't Move

Verified rather than recalled. Re-check before relying on them in a year.

**Core Web Vitals** — field metrics at the 75th percentile; all three must
pass together:

| Metric | Good | Needs improvement | Poor |
|--------|------|-------------------|------|
| LCP | ≤2.5s | 2.5–4.0s | >4.0s |
| INP | ≤200ms | 200–500ms | >500ms |
| CLS | ≤0.1 | 0.1–0.25 | >0.25 |

Plus FCP ≤1.8s, TBT ≤200ms, Lighthouse ≥90. For scale: as of May 2026 CrUX
data, 55.9% of tracked origins pass all three, with mobile LCP the hardest at
62% good.

**Motion accessibility** — two criteria, and the distinction matters:

- **SC 2.3.3 Animation from Interactions (AAA)** covers motion the *user*
  triggers — scroll parallax, click-triggered animation. Must be disableable
  unless essential. Sufficient technique: `prefers-reduced-motion` (C39 in
  CSS, SCR40 in JS).
- **SC 2.2.2 Pause, Stop, Hide (Level A)** covers motion the *page* starts —
  autoplaying hero loops, marquees, carousels. Anything running over five
  seconds needs a pause control. **Almost every motion site has the
  autoplaying hero; almost none has the control.**

Step 5 requires a reduced-motion matrix row for every single effect, and the
authored CSS default is the *end state* — motion goes inside
`@media (prefers-reduced-motion: no-preference)`, so a missed override fails
safe rather than leaving content at `opacity: 0`.

---

## Three Rules That Carry The Build

**Content, then style, then motion.** Step 6 completes each pass across the
whole site before starting the next. Pass 1 must read correctly with CSS
disabled; pass 2 must be fully usable with JavaScript off. Built the other way
round, every failure is total; built this way, every failure is cosmetic.

**No claim without proof.** Round 4 collects what you can actually claim, with
permission status per item. Anything outside that list doesn't get softened —
it gets cut. The three that end careers, called out explicitly: a logo used
without permission, a testimonial written by the site's author, a certification
claimed but not held.

**The gate doesn't move.** A tier-4 WebGL scene that breaks LCP gets
lazy-loaded; if that doesn't clear it, the effect is cut. Motion that can't be
disabled is the one defect on the audit list that can physically harm a
visitor, so it's a hard ship blocker.

---

## Notes

Output files are in `.gitignore` — they're artefacts of one project. Seven
things are worth copying forward, and they compound: `tokens.css`, the
component CSS, the motion scaffolding and its matrix, the section templates,
the grill question set, the reference library, and the audit checklist.

The grill is the part that improves hardest with use. After each site, add the
question you wished you'd asked — a better question up front saves a rebuild
later.
