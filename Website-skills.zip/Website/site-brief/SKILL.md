---
name: site-brief
description: >
  Step 1 of 8 in the Motion Site Engine Pipeline. The grill. Interrogates the
  owner across seven rounds — product, visitor, job, proof, taste, constraints,
  motion appetite — and refuses to proceed on thin answers. Produces the brief
  and brand voice guide that every downstream step reads. No site gets built
  from assumptions. Saves as site_brief.md.
---

# Site Brief — The Grill

Every generic website was built from a generic brief.
Not because the builder lacked taste, but because nobody was asked
the questions that would have made the answer specific.
So this step asks them. All of them. Before anything is designed.
Thin answers get sent back, not worked around.
Save as `site_brief.md`.

---

## The Grill Philosophy

```
WHY THIS STEP IS THE WHOLE PIPELINE:
  A site built on "a modern site for my AI product" can only be generic,
  because every decision downstream has to be guessed. A site built on
  "developers who already pay for three tools and resent the fourth, landing
  from a Show HN thread, who need to see the token saving in under ten
  seconds" has its hero, its first section, its proof and its motion brief
  already decided.

  The grill is not admin. It is the design work, done in questions.

THE REFUSAL RULE:
  Each round has a pass bar. An answer that does not clear it gets ONE
  follow-up question, then the round is marked THIN and recorded as such.
  A brief with three or more THIN rounds does not advance — the gate says
  so explicitly and names which rounds need work.
  Guessing on the owner's behalf is the failure this step exists to prevent.

WHO ANSWERS:
  The owner. If the owner is not available, the step stops and says so
  rather than inventing answers. The one exception is an unattended run,
  where the step takes its best reading of what is on file, marks every
  assumption with ⚠️ ASSUMED, and puts them at the top of the brief for
  correction.

HOW TO ASK:
  □ Where the interface offers a question tool, ask in batches of 2-4
    rounds with concrete options, not open prose boxes
  □ Never ask a question the brief already answers
  □ Never ask more than one follow-up per round — past that, record THIN
    and move on
  □ Offer a reference-driven shortcut: "point me at three sites you'd be
    happy to be compared to" does more work than ten adjective questions

THE RULE:
  Never design before Round 7 is answered.
  Never invent a proof claim the owner did not give you.
  Never accept "modern, clean, professional" as a taste answer.
  Never let a site have two primary conversions.
```

---

## Round 1 — The Product

```
ASK:
  1. What is it, in one sentence a stranger would understand?
  2. What does someone use INSTEAD of it today? (Name the incumbent, or
     "nothing — they live with the problem.")
  3. What is the single thing it does better than that alternative?
  4. What does it cost, and what is the pricing model?
  5. What stage is it at — idea, beta, launched, revenue?
  6. What does it NOT do, that people assume it does?

PASS BAR:
  □ Q1 answered without jargon and without the word "platform"
  □ Q2 names a real alternative
  □ Q3 is one thing, not a list
  □ Q4 has a number or an explicit "not decided yet"

THE ONE-SENTENCE TEST:
  Read Q1 back. If it would also describe three competitors, it is not
  specific enough. Ask: "what would a competitor NOT be able to say?"

RECORD:
  Product: [...]
  Incumbent: [...]
  The one better thing: [...]
  Pricing: [...]
  Stage: [...]
  Common misconception: [...]
  Round verdict: [PASS / THIN]
```

---

## Round 2 — The Visitor

```
ASK:
  1. Who lands on this page? Role, context, what they were doing before.
  2. Where do they come from? (search, a launch post, a link in a DM, an
     ad, a conference badge)
  3. What do they already believe about this category?
  4. What have they already tried that did not work?
  5. What is the objection they arrive with?
  6. How much do they know — do I explain the category or assume it?

PASS BAR:
  □ Q1 names a role and a context, not a demographic
  □ Q2 names at least one real traffic source
  □ Q5 is a specific objection, not "they might not trust it"

WHY Q2 DECIDES THE HERO:
  A visitor from a launch post needs the product named and shown in four
  seconds. A visitor from a search for the incumbent's name needs the
  comparison. A visitor from a DM already has social proof and needs the
  mechanism. Same product, three different heroes. This is the question
  most briefs skip and most sites suffer for.

RECORD:
  Primary visitor: [...]
  Traffic sources, ranked: [...]
  Prior beliefs: [...]
  Failed alternatives: [...]
  Arrival objection: [...]
  Category knowledge: [assume / explain]
  Round verdict: [PASS / THIN]
```

---

## Round 3 — The Job

```
EVERY PAGE HAS EXACTLY ONE PRIMARY CONVERSION. NAME IT.

ASK:
  1. What is the ONE action a visit should end in?
  2. How would you know, in numbers, that the site is working?
  3. What is the secondary action, for people not ready for the first?
  4. What happens immediately after they convert?
  5. Is there anything you need them to read before converting (pricing,
     a limitation, a requirement)?

PASS BAR:
  □ Q1 is one action, measurable, with a verb
  □ Q2 has a number or a named metric
  □ Q3 is genuinely lower-commitment than Q1

TWO PRIMARY CONVERSIONS IS THE MOST COMMON BRIEF FAILURE:
  "Sign up and book a demo" is two sites. Pick the one the business needs
  this quarter; the other becomes the secondary action. If the owner cannot
  pick, ask which one they would keep if the other were removed.

THE CONVERSION LADDER (fill in all three):
  Primary   : [the action]           → measured by [metric]
  Secondary : [lower commitment]     → for [who]
  Tertiary  : [zero commitment]      → for [who] (newsletter, docs, repo)

RECORD:
  Round verdict: [PASS / THIN]
```

---

## Round 4 — The Proof

```
THIS ROUND DECIDES WHETHER THE SITE CAN BE CREDIBLE. BE EXACT.
Every reference site in the brief's taste round earns trust with specific
numbers, never round ones. You cannot write those numbers in Step 3 if you
do not collect them here.

ASK — and take only what actually exists:
  1. Customer or user count? Exact number, as of a date.
  2. Named customers you have permission to show as logos?
  3. Testimonials with a real name, role and company?
  4. Case studies with an outcome metric?
  5. Usage numbers? (requests, hours saved, tokens, sessions, downloads)
  6. Revenue or growth figures you are willing to publish?
  7. Third-party signals — awards, reviews, ratings, press?
  8. Certifications or compliance — ISO, SOC 2, GDPR posture?
  9. Open-source repo, stars, public changelog?
 10. Founder credibility that is relevant, not decorative?

PASS BAR:
  □ At least TWO items answered with something concrete
  □ Every number carries a date
  □ Every logo and testimonial carries explicit permission

THE PERMISSION GATE:
  □ Logo use confirmed in writing for each named customer
  □ Testimonial wording approved by the person quoted
  Anything without permission is recorded as UNUSABLE and does not reach
  Step 3. Using a logo you have not cleared is the kind of mistake that
  outlives the site.

IF PROOF IS EMPTY — the honest paths, in order of preference:
  1. The transparent-build route. Publish what is true: what you are
     making, where it is, what works today. A build-in-public page with
     real numbers beats a launched-looking page with invented ones.
  2. The mechanism route. Show HOW it works in enough depth that the
     method is the proof. An interactive demo substitutes for social proof
     better than anything else available to a new product.
  3. The founder route. Your own track record, if it is relevant.
  4. The specificity route. Precise claims about what the product does,
     with no claims about who uses it.
  NEVER: invented counts, stock-photo testimonials, "trusted by thousands",
  fake logo walls, borrowed review scores, placeholder star ratings left in.

RECORD:
  | Proof item | Specific value | As of | Permission | Usable |
  |------------|----------------|-------|------------|--------|
  Usable proof items: [N]
  Round verdict: [PASS / THIN / EMPTY → route chosen: [N]]
```

---

## Round 5 — The Taste

```
ADJECTIVES ARE WORTHLESS HERE. REFERENCES ARE EVERYTHING.

ASK:
  1. Name three sites you would be happy to be compared to. Any industry.
  2. For each: what specifically do you like? (the type, the motion, the
     colour, the structure, the tone)
  3. Name one site in your space you actively dislike, and why.
  4. Do you have brand assets already — logo, colours, type, a design
     system? Send them or say no.
  5. Light, dark, or both?
  6. Three words for the tone. Then: what would the OPPOSITE site look
     like? (this second question is where the real answer lives)
  7. Any hard brand rules — a font you must use, a colour you cannot use,
     a logo lockup?

PASS BAR:
  □ Three references named, with a specific reason each
  □ Q3 answered — knowing what to avoid is half the brief
  □ Q4 resolved either way
  □ Q6's opposite question answered

BANNED TASTE ANSWERS — ask the follow-up instead:
  "modern"        → which of your three references is most modern, and why?
  "clean"         → clean like a Swiss poster, or clean like an iOS setting?
  "professional"  → professional like a bank, or like a design studio?
  "fun"           → fun like a children's app, or like a sharp joke?
  "premium"       → premium like a watch brand, or like enterprise software?

WHERE THE OWNER HAS A SAVED DESIGN SYSTEM:
  Use it. Ask whether this site should follow it exactly, extend it, or
  deliberately depart from it — and record which. A site that half-follows
  a brand reads as a mistake rather than a choice.

RECORD:
  References: [3, with the specific reason each]
  Anti-reference: [site + why]
  Existing assets: [list / none]
  Mode: [light / dark / both]
  Tone: [3 words] · Opposite: [description]
  Hard rules: [...]
  Round verdict: [PASS / THIN]
```

---

## Round 6 — The Constraints

```
ASK:
  1. Which pages do you actually need? (the default set is below — cut and
     add from it)
  2. When does it need to be live?
  3. Where is it hosted, and do you have the domain?
  4. Does anything need to be editable by a non-developer later?
  5. Any integrations — payments, auth, booking, email capture, analytics,
     a form endpoint?
  6. Any legal requirements — cookie consent, privacy policy, accessibility
     statement, regulated-industry disclosures?
  7. Languages, now or planned?
  8. Who maintains it after handover?

THE DEFAULT PAGE SET for a full multi-page site:
  □ Home
  □ Features (or Product, or How it works)
  □ Pricing
  □ Docs or Resources
  □ About
  □ Blog or Changelog shell
  □ Contact
  □ Legal: Privacy, Terms, Cookies
  □ Utility: 404, thanks/confirmation
  Cut ruthlessly. A five-page site that is finished beats a nine-page site
  that is half-written.

PASS BAR:
  □ Page list agreed and counted
  □ Hosting and domain status known
  □ Integrations listed or explicitly none
  □ Editability answered — it decides whether this is static HTML or needs
    a CMS, and that is the biggest architectural fork in the pipeline

RECORD:
  Pages: [list, N total]
  Deadline: [...]
  Hosting: [...] · Domain: [...]
  Editable by non-dev: [yes → what / no]
  Integrations: [...]
  Legal: [...]
  Languages: [...]
  Maintainer: [...]
  Round verdict: [PASS / THIN]
```

---

## Round 7 — The Motion Appetite

```
"MAKE IT MOTION" MEANS DIFFERENT THINGS AT DIFFERENT BUDGETS. CALIBRATE IT.

ASK:
  1. On a scale, where should this sit?
     TIER 1 RESTRAINED — fades, small reveals on scroll, hover states.
                         Fast everywhere. The safe, professional default.
     TIER 2 CHOREOGRAPHED — scroll-linked sequences, pinned sections,
                         counters, staged reveals, a looping hero visual.
                         The common shape of a good product site.
     TIER 3 INTERACTIVE — a thing the visitor plays with: a live demo, a
                         drag interaction, a configurator, a toy. Plus
                         Tier 2 throughout.
     TIER 4 SHOWPIECE — WebGL, 3D, custom shaders, cursor-driven scenes,
                         an experience that is itself the proof of craft.
                         Expensive to build, expensive to maintain, and it
                         must still pass the performance gates.
  2. Is there one moment you want people to screenshot and share?
  3. Does the product itself have something that can be shown live rather
     than described?
  4. Anyone in the audience likely to be motion-sensitive, or on slow
     connections or old devices?
  5. Is there an existing video, 3D asset, or product recording to use?

PASS BAR:
  □ A tier chosen
  □ Q3 answered — it decides whether Step 5 builds a real demo or a
    simulated artefact
  □ Q4 answered — it sets how aggressive the reduced-motion fallback is

THE INTERACTIVE ARTEFACT QUESTION IS THE IMPORTANT ONE:
  Across the reference sites, the single thing that separates a good site
  from a memorable one is one element the visitor can operate that is not
  a form. A toggle between two product modes, a message encoder, an
  approve/decline card, a draggable gallery, a revenue chart with a filter.
  Step 5 will build one. This round decides what it is.

  Candidates for this product: [list at least two]
  Chosen: [...]

RECORD:
  Tier: [1-4]
  Signature moment: [...]
  Live-demonstrable: [yes → what / no → simulate what]
  Motion sensitivity concerns: [...]
  Existing assets: [...]
  Interactive artefact: [...]
  Round verdict: [PASS / THIN]
```

---

## BRAND_VOICE.md

```
WRITE THIS FROM ROUNDS 1, 2 AND 5. STEP 3 READS IT EVERY PASS.

  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BRAND VOICE: [Product]

  WHO WE ARE TALKING TO:
  [Round 2's visitor, in one sentence, with their arrival objection.]

  HOW THIS SITE SOUNDS:
  [3-5 sentences from Round 5's tone words and its opposite.]

  THE ONE SENTENCE:
  [Round 1 Q1, final wording. This appears on the site verbatim.]

  WE SAY / WE DON'T SAY:
  □ [term we use]        not [term we avoid]
  □ [term we use]        not [term we avoid]

  CLAIMS WE CAN MAKE:
  [Only Round 4's usable proof. Nothing else is claimable.]

  CLAIMS WE CANNOT MAKE:
  [Everything marked UNUSABLE, and why.]

  SENTENCE RHYTHM:
  [Short and declarative? Long setup then verdict? Match the references.]

  WHAT THIS VOICE NEVER SAYS:
  □ "revolutionary" / "cutting-edge" / "seamless" / "robust"
  □ "we're excited to announce"
  □ "leverage" / "utilise" as filler
  □ "it's not just X, it's Y"
  □ "trusted by thousands" without a number
  □ Any claim from the CANNOT list above
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Output File: site_brief.md

```markdown
# Site Brief
Pipeline step: 1 of 8
Date: [date]

---

## ⚠️ Assumptions (unattended runs only)
[Any ⚠️ ASSUMED answer, listed first for correction. Delete if none.]

---

## Round 1 — Product
[all fields] · Verdict: [PASS/THIN]

## Round 2 — Visitor
[all fields] · Verdict: [PASS/THIN]

## Round 3 — The Job
Primary: [...] → [metric]
Secondary: [...]
Tertiary: [...]
Verdict: [PASS/THIN]

## Round 4 — Proof
| Proof item | Value | As of | Permission | Usable |
|------------|-------|-------|------------|--------|
Usable items: [N] · Unusable: [N]
Verdict: [PASS/THIN/EMPTY → route N]

## Round 5 — Taste
[all fields] · Verdict: [PASS/THIN]

## Round 6 — Constraints
Pages: [list, N] · [all fields] · Verdict: [PASS/THIN]

## Round 7 — Motion
Tier: [N] · Interactive artefact: [...] · Verdict: [PASS/THIN]

---

## BRAND_VOICE.md
[Full voice guide]

---

## Brief Scorecard

| Round | Verdict |
|-------|---------|
| 1 Product | [...] |
| 2 Visitor | [...] |
| 3 Job | [...] |
| 4 Proof | [...] |
| 5 Taste | [...] |
| 6 Constraints | [...] |
| 7 Motion | [...] |

PASS: [N]/7 · THIN: [N]/7
BUILDABLE: [YES if THIN ≤2 / NO]

---

## Pipeline Status
Step 1 ✅ site-brief     → site_brief.md
Step 2 ⬜ site-architect → site_map.md
Step 3 ⬜ site-copy      → site_copy.md
Step 4 ⬜ site-design    → design_system.md
Step 5 ⬜ site-motion    → motion_spec.md
Step 6 ⬜ site-build     → build_log.md
Step 7 ⬜ site-audit     → quality_report.md
Step 8 ⬜ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `site_brief.md`, present this EXACTLY:

```
✅ Brief complete. Saved to site_brief.md.

📋 Summary:
- Product      : [one sentence]
- Visitor       : [role], arriving from [source]
- Primary job   : [action] → measured by [metric]
- Usable proof  : [N] items ([N] unusable — [reasons])
- References    : [3 sites]
- Pages         : [N] — [list]
- Motion tier   : [N] — [name]
- Interactive   : [the artefact]

Brief scorecard: [N]/7 PASS · [N]/7 THIN
BUILDABLE: [YES / NO]

[IF THIN rounds] ⚠️ These rounds need better answers before the site can
be specific rather than generic:
  Round [N] — [what is missing, and the one question that would fix it]

[IF THIN ≥3] 🛑 Too much is unknown to build something that is not
generic. Answer the rounds above and I will rerun the brief. I am not
going to guess these for you — guessing is how sites end up looking like
every other site.

[IF proof EMPTY] ⚠️ No usable proof. Taking route [N]: [the honest path].
No invented counts, logos or testimonials will appear anywhere in this
site.

👉 Review site_brief.md. You can:
  - Approve → say "approved" or "architect the site"
  - Answer a round → say "Round [N]: [your answer]"
  - Change the motion tier → say "tier [N]"
  - Add or cut a page → say "add [page]" / "drop [page]"
  - Change the primary job → say "primary is [action]"

⏸️ Waiting for approval before Architect runs.
```

**NEVER** proceed automatically.

**NEVER** proceed with 3 or more THIN rounds.

**NEVER** invent a proof claim, a logo or a testimonial.

Approval keywords: `approved`, `architect the site`, `architect`,
`proceed`, `next`, `go`, `looks good`, `brief approved`
