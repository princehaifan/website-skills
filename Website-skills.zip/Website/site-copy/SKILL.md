---
name: site-copy
description: >
  Step 3 of 8 in the Motion Site Engine Pipeline. Takes site_brief.md and
  site_map.md and writes every word of every page in the chosen heading
  grammar and brand voice: hero, capability sections, proof with specific
  numbers, pricing, FAQ, closing CTA, plus all microcopy, form states, empty
  states, 404, meta and OG tags. No placeholder text reaches the build.
  Saves as site_copy.md.
---

# Site Copy

Every word on the site gets written here, including the ones nobody plans:
the button that says what happens next, the error that says what went wrong,
the empty state, the 404, the tab title.
Lorem ipsum is not a placeholder. It is a decision to write it later,
and later is after the layout has hardened around the wrong length.
Save as `site_copy.md`.

---

## The Copy Rules

```
LOAD BEFORE WRITING:
  BRAND_VOICE.md   — every pass, in full
  site_brief.md    — Round 4's usable proof is the ONLY claimable material
  site_map.md      — the section plan and the chosen heading grammar

THE FIVE HARD RULES:
  1. EVERY WORD GETS WRITTEN. Headings, body, buttons, labels, placeholders,
     helper text, validation errors, success states, empty states, loading
     states, 404, 500, cookie banner, footer, meta title, meta description,
     OG title, OG description, image alt text. If it renders, it is written
     here.
  2. NO CLAIM WITHOUT PROOF. Round 4's usable list is the boundary. A claim
     outside it does not get softened — it gets cut.
  3. EVERY NUMBER IS SPECIFIC. "15,000+ clients" not "thousands".
     "$1,192,765 in 12 months" not "over a million". The reference sites win
     trust on precision: 177M+ IPs, 195 locations, 51,492 subscribers,
     1.2 million projects weekly. A round number reads as an estimate.
  4. ONE GRAMMAR PER PAGE. The grammar chosen in Step 2 governs every
     section heading on that page.
  5. THE PRIMARY CTA LABEL NEVER VARIES. Same words in the nav, the hero,
     mid-page, pricing and the closing section.

LENGTH DISCIPLINE — "more copy" means more substance, not more words:
  □ Every sentence carries a fact, a number, a mechanism or an instruction
  □ A sentence that only sets up the next sentence gets cut
  □ Write long on mechanism and proof; write short on claims

THE RULE:
  Never write lorem ipsum, "[Feature name]", or "Lorem headline here".
  Never write a testimonial. Quote one, or leave the section out.
  Never invent a customer name, a logo, a rating or a count.
  Never let two sections make the same point in different words.
```

---

## The Hero

```
FOUR PARTS, IN THIS ORDER. THE WHOLE PAGE DEPENDS ON THEM.

  1. HEADLINE — 4-9 words
     THE TEST: would a competitor be unable to say it?
       "Fresh Web Data for Grounding AI Agents"   (oxylabs — specific)
       "Build something Lovable"                   (lovable — brand-led)
       "Your best focus starts here."              (trylatent — outcome)
       "Made for mugs. Built for tables."          (oryzo — product-led)
       "I was fired everywhere, so I built 43 startups."  (marclou — story)
     FIVE SHAPES:
       OUTCOME   "Your best focus starts here."
       MECHANISM "The whole web, one API call away."
       CATEGORY  "Fresh web data for grounding AI agents."
       BRAND     "Build something Lovable."
       STORY     a first-person line with a number in it
     □ No colon-subtitle constructions ("Acme: the platform for X")
     □ No "the #1" or "the leading" without a citable source
     □ Reads correctly at 2 lines on mobile — count the characters

  2. SUBHEAD — 12-28 words, one sentence
     Its job is the thing the headline could not carry: who it is for, or
     how it works.
       "Give your agents the whole web. Live search and structured
        extraction through one API – built for scale."        (oxylabs)
       "Latent turns your distracting phone into proof of your work,
        helping you lock in now and motivating you to do it again."
                                                             (trylatent)
     □ Names the mechanism or the audience, not both
     □ No second claim — the headline owns the claim

  3. CTAS — primary + secondary
     □ Primary: verb + object. "Get started" is weaker than "Start for
       free" is weaker than "Create your first project".
     □ Secondary: lower commitment and visibly subordinate. "Talk to
       expert", "Watch the launch", "Read the docs".
     □ Never two primaries.

  4. THE REASSURANCE LINE — one line under the CTAs, optional but high-value
     "No credit card. $5 starter credit." / "Free while in beta."
     □ Answers the hesitation the CTA creates
     □ Must be true

WRITE THREE HEADLINE OPTIONS AND PICK ONE. Record the two you rejected —
they are the A/B test later.
```

---

## Capability Sections

```
ONE SECTION, ONE IDEA. FOUR PARTS EACH.

  1. EYEBROW (optional)  — 1-3 words, the category label. "Trust",
                           "Infrastructure", "Pricing". oxylabs labels
                           every section this way.
  2. HEADING             — in the page's grammar, from Step 2
  3. BODY                — 2-4 sentences, or 3-5 bullets. Never both.
  4. LINK                — "Learn more" / "See all stories" / "Read the docs"

  THE BODY'S JOB, IN ORDER:
    Sentence 1 — what it does, concretely
    Sentence 2 — how it works, named mechanism
    Sentence 3 — what that gets the visitor, with a number if one exists
    Sentence 4 — the limit or the requirement, if there is one

  WRITING TO EACH GRAMMAR:
    G1 "Hosting, handled."
       → body explains what "handled" covers, item by item
    G2 "01 Record"
       → body is instructional, present tense, second person
    G3 "Enterprise-grade by default."
       → body is the evidence for the claim, nothing else
    G4 "Hire a bot, not a chatbot."
       → body draws the contrast explicitly, often as two lists
    G5 "So portable, it's wearable"
       → body commits to the joke, then lands one real fact

  □ No section body exceeds 60 words without a bullet list
  □ Every bullet starts with the same part of speech
  □ The link label says where it goes, never "click here"
```

---

## Writing Proof

```
THIS IS WHERE SITES ARE BELIEVED OR NOT. USE ONLY ROUND 4'S USABLE LIST.

  LOGO WALL
    □ A count beside it: "Trusted by 15,000+ businesses" with the logos
    □ Logos only where permission is on file
    □ 6-12 logos. Fewer looks thin; more looks like a directory.

  STAT ROW
    □ 3-4 stats, each a specific number with a unit and a label
    □ "177M+ IPs · 195 locations · 15,000+ clients"
    □ Each stat dated in the source notes, even if not shown on the page

  TESTIMONIAL
    □ Name, role, company. A quote with no attribution is worth nothing.
    □ Quote the outcome, not the adjective. "Cut our support tickets by
      40%" beats "Great product, highly recommend."
    □ Keep it under 40 words. Trim with an ellipsis rather than paraphrase —
      never reword someone's quote.

  CASE STUDY CARD
    □ Lead with the metric, not the company name
    □ Company · outcome metric · one line of context · "Read [company]"
    □ lovable's four cards each lead with a number: cost savings, ticket
      reduction, ARR, build time

  TRUST STACK (B2B)
    □ Name the certification exactly: "ISO/IEC 27001:2022", "SOC 2 Type II"
    □ Never imply a certification in progress is held
    □ Link to the trust centre or the certificate

  SHIPPING FEED
    □ 3-5 recent items, each dated, each one line
    □ This is the cheapest credibility on the list and it compounds

  IF PROOF IS EMPTY — write to the route chosen in Round 4:
    Route 1 transparent-build → "What works today" / "What's next", dated,
                                honest about the gaps
    Route 2 mechanism         → the interactive artefact carries the weight;
                                write the section that explains the method
    Route 3 founder           → one short paragraph, relevant only
    Route 4 specificity       → precise product claims, zero social claims
    □ NEVER a logo wall of "companies like yours"
    □ NEVER a star rating with no source
    □ NEVER "join thousands of users"
```

---

## Pricing Copy

```
THE PAGE PEOPLE READ MOST CAREFULLY. BE UNAMBIGUOUS.

  PER TIER:
    Name · price · billing period · who it is for (one line) · what is
    included (5-8 items) · the CTA · any limit

  □ Price as a numeral with its currency and period: "£19/month"
  □ Annual discount stated as both the percentage and the saved amount
  □ One tier marked recommended, with a reason, not just a badge
  □ Every included item is a thing, not a benefit ("10 seats", not
    "scales with your team")
  □ Limits stated plainly in the tier, not in a footnote
  □ Usage-based pricing: publish the unit rate. bops lists $0/month base,
    hourly compute, AI at cost, $3/month per phone number — that openness
    is the trust device.

  THE THREE QUESTIONS EVERY PRICING PAGE MUST ANSWER IN COPY:
    1. What happens when I hit a limit?
    2. Can I cancel, and what happens to my data?
    3. What is NOT included at this price?
  □ Answer all three, in the tiers or the pricing FAQ

  ENTERPRISE / "CONTACT US" TIER:
  □ Say what it adds, not just "custom". SSO, SLA, DPA, dedicated support,
    invoicing — name them.
```

---

## FAQ

```
AN FAQ IS NOT PADDING. IT IS WHERE OBJECTIONS GO TO DIE.

  SOURCE THE QUESTIONS, DO NOT INVENT THEM:
    1. Round 2's arrival objection — always the first question
    2. The three pricing questions above
    3. Whatever support or DMs actually get asked
    4. The Round 1 misconception — "what it does NOT do"

  trylatent's FAQ covers pricing, camera use, app blocking, breaks,
  privacy, friends, platform availability. Every one is a real hesitation,
  not a marketing prompt.

  WRITING RULES:
  □ 5-9 questions. More means the page above is not doing its job.
  □ Questions in the visitor's words, first person: "Can I use this
    offline?" not "Offline capability"
  □ Answers 1-3 sentences, leading with yes or no where it is a yes/no
  □ Never use the FAQ to make a claim you avoided above
  □ Never answer a question nobody asks to show off a feature
```

---

## Microcopy

```
THE COPY NOBODY BRIEFS, THAT EVERY VISITOR READS.

  BUTTONS AND LINKS
    □ Verb + object. "Download the guide" not "Submit"
    □ The label says what happens, not what to do
    □ Loading state for every button that waits: "Starting…", "Sending…"

  FORMS — for every field:
    □ Label (always visible, never placeholder-only)
    □ Placeholder, if it adds an example rather than repeating the label
    □ Helper text where the requirement is not obvious
    □ Validation error, specific: "Enter an email address" not "Invalid"
    □ Required-field marking
  Newsletter / contact / signup — write all states:
    □ Empty · focused · invalid · submitting · success · server error

  STATES
    □ Empty state: what goes here and how to add the first one
    □ Loading: what is happening
    □ Error: what went wrong and what to do next. Never "Something went
      wrong" alone.
    □ Success: confirm what happened and name the next step

  UTILITY PAGES
    □ 404: say it is missing, offer the three most useful links, keep the
      voice. No cleverness that delays the exit.
    □ Thanks / confirmation: what happens next and when
    □ Cookie banner: plain language, honest options, decline as easy as
      accept

  NAV AND FOOTER
    □ Every nav label 1-2 words
    □ Footer column headings
    □ Legal link labels
    □ Copyright line with the entity name
    □ Newsletter prompt and its button
```

---

## Meta, Social and Alt Text

```
PER PAGE, WRITE ALL OF THESE:

  □ <title>           50-60 characters. Primary term first, brand last.
                      "Pricing — [Product]" not "[Product] | Pricing Page"
  □ meta description  140-160 characters. A sentence that earns the click;
                      it is not a ranking factor but it is the ad copy.
  □ OG title          Can differ from <title>; optimise for a shared link
  □ OG description    110-140 characters
  □ OG image alt      Describe it for screen readers
  □ Twitter card type summary_large_image, unless there is a reason
  □ Canonical URL
  □ JSON-LD           Organization on the home page; Product or
                      SoftwareApplication where it applies; FAQPage on the
                      FAQ; BreadcrumbList on deep pages

  ALT TEXT — every image on every page:
  □ Decorative images: alt="" (empty, not missing)
  □ Meaningful images: describe the information, not the appearance
  □ Logos in a wall: the company name
  □ Screenshots: what the screenshot demonstrates, not "screenshot of app"
  □ Never start with "Image of" or "Picture of"

  □ No two pages share a <title> or a meta description
```

---

## Writing Sequence

```
WRITE IN THIS ORDER:
  1. The hero — three headline options, pick one
  2. The closing CTA — write it second. Knowing where the page lands tells
     you what the middle has to establish.
  3. Capability sections, in page order
  4. Proof sections — only from the usable list
  5. Pricing
  6. FAQ
  7. Microcopy, states, utility pages
  8. Meta, OG, alt text
  9. Re-read the hero against everything below it and rewrite it

WHY THE HERO IS WRITTEN TWICE:
  The first draft is a guess at the promise. After writing the body you
  know what the page can actually deliver. The reference sites all have
  heroes that match their bodies exactly, and that only happens on a rewrite.

BATCH RULES:
  □ After each page, re-read BRAND_VOICE.md
  □ Log per section: word count · proof used · claims made
  □ Mark anything you cannot substantiate [NO PROOF] — do not soften it
  □ Mark anything needing an asset [ASSET NEEDED: description]
```

---

## Output File: site_copy.md

```markdown
# Site Copy
Pipeline step: 3 of 8
Date: [date]
Reads: site_brief.md, site_map.md, BRAND_VOICE.md

---

## Global

Primary CTA: "[label]"
Secondary CTA: "[label]"
Grammar: G[N]

---

## Page: Home — /

### Meta
title: [...]
description: [...]
og:title / og:description / og:image alt: [...]
JSON-LD: [types]

### 1. Hero
Headline: [...]
  Rejected: [option 2] · [option 3]
Subhead: [...]
Primary CTA: [...] · Secondary CTA: [...]
Reassurance: [...]

### 2. [Section]
Eyebrow: [...]
Heading: [...]
Body: [...]
Link: [...]
Proof used: [...]

[...all sections]

### Closing CTA
Heading: [...] · Body: [...] · CTA: [...]

---

## Page: [next] — /[url]
[full copy]

---

## Pricing
| Tier | Price | For | Includes | CTA | Limits |
|------|-------|-----|----------|-----|--------|

The three questions answered: [where]

---

## FAQ
Q: [...] → A: [...]
Source of each question: [objection / pricing / support / misconception]

---

## Microcopy
Buttons: [all labels + loading states]
Forms: [every field, all 6 states]
Empty / loading / error / success: [...]
404: [...] · Thanks: [...] · Cookie banner: [...]
Nav labels · Footer columns · Legal labels · Copyright

---

## Alt Text
| Image | Page | Alt |
|-------|------|-----|

---

## Copy Ledger
| Page | Sections | Words | Claims | Proof used | Flags |
|------|----------|-------|--------|------------|-------|

Total words: [N]
[NO PROOF] flags: [list or none]
[ASSET NEEDED] flags: [list or none]
Placeholder text remaining: 0

---

## Pipeline Status
Step 1 ✅ site-brief     → site_brief.md
Step 2 ✅ site-architect → site_map.md
Step 3 ✅ site-copy      → site_copy.md
Step 4 ⬜ site-design    → design_system.md
Step 5 ⬜ site-motion    → motion_spec.md
Step 6 ⬜ site-build     → build_log.md
Step 7 ⬜ site-audit     → quality_report.md
Step 8 ⬜ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `site_copy.md`, present this EXACTLY:

```
✅ Copy complete. Saved to site_copy.md.

📋 Summary:
- Pages written : [N]
- Sections      : [N]
- Total words   : [N]
- Claims made   : [N], all traced to Round 4's usable proof
- Grammar held  : G[N] across [N]/[N] pages
- Microcopy     : [N] buttons · [N] form fields × 6 states · 404 · cookie
- Meta          : [N] titles, [N] descriptions, all unique
- Alt text      : [N] images

The hero:
  "[headline]"
  "[subhead]"
  [primary CTA] · [secondary CTA]
  Rejected headlines: "[2]" · "[3]"

Checks:
  Placeholder text    : [N] (must be 0)
  [NO PROOF] flags    : [N]
  [ASSET NEEDED] flags: [N]
  Duplicate meta      : [N] (must be 0)
  CTA label varies    : [N] (must be 0)

[IF NO PROOF flags] ⚠️ [N] claims have no proof behind them and have been
CUT, not softened: [list]. If proof exists, give it to me and I will put
them back.

[IF ASSET NEEDED] ⚠️ [N] assets needed before the build: [list]

👉 Review site_copy.md. You can:
  - Approve → say "approved" or "design the system"
  - Swap the headline → say "use rejected headline [N]"
  - Rewrite a section → say "rewrite [page] section [N]"
  - Change the CTA → say "primary CTA is [label]"
  - Add proof → say "we also have [proof]"
  - Cut length → say "tighten [page]"

⏸️ Waiting for approval before Design runs.
```

**NEVER** proceed automatically.

**NEVER** ship placeholder text, an invented testimonial, or an uncleared logo.

Approval keywords: `approved`, `design the system`, `design`,
`proceed`, `next`, `go`, `looks good`, `copy approved`
