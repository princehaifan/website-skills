---
name: site-ship
description: >
  Step 8 of 8 in the Motion Site Engine Pipeline. Takes quality_report.md and
  ships: publishes the site, wires the domain and DNS, sets analytics and
  consent, submits the sitemap, records the performance baseline, writes the
  handover document for whoever maintains it, and archives every artefact
  plus the reusable assets that make the next site faster. The pipeline ends
  here. Saves as publish_log.md.
---

# Site Ship

The audit passed. Now put it where people can reach it,
and leave behind enough that the next person — including future-you —
can change it without reverse-engineering it.
A site nobody can edit is a site that rots.
Then keep the design system, the token file and the component library,
because the next site starts from those, not from nothing.
Save as `publish_log.md`.

---

## Ship Overview

```
WHAT LEAVES THIS STEP:
  1. THE LIVE SITE    published, reachable, on the right domain
  2. THE DOMAIN       DNS, HTTPS, canonical host, redirects
  3. ANALYTICS        measurement wired, consent-gated where required
  4. SEARCH           sitemap submitted, indexing verified
  5. THE BASELINE     field numbers to measure against later
  6. THE HANDOVER     how to edit it, written for a non-author
  7. THE ARCHIVE      every artefact, plus the reusable kit

THE RULE:
  Never ship with a FAIL in quality_report.md.
  Never point a domain at an unverified deploy — preview first.
  Never load analytics before consent where consent is required.
  Never hand over without a document that says how to change the copy.
```

---

## Step 1 — Pre-Ship Checklist

```
BLOCK THE SHIP IF ANY OF THESE FAIL:

FROM quality_report.md:
  □ All eight checks PASS
  □ Blockers outstanding: 0
  □ SHIP READY: YES
  → If NO, stop. Return to Step 7.

FINAL SWEEP, ON THE ACTUAL BUILD OUTPUT:
  □ Placeholder grep clean: lorem · TODO · example.com · [bracket] · 0
  □ Default favicon replaced
  □ Test/staging analytics IDs replaced with production
  □ Any hardcoded localhost or preview URL removed
  □ No .env, no API keys, no credentials in the deployed files — grep for
    "key", "secret", "token", "password" in everything shipping
  □ Source maps: intentionally included or excluded, decided
  □ robots.txt is the production one, not a staging disallow-all
  □ Legal pages are real text, not placeholders
  □ Contact details correct and monitored

⚠️ THE STAGING ROBOTS FILE IS THE MOST COMMON LAUNCH FAILURE. A site that
launches with `Disallow: /` can sit unindexed for weeks. Check it explicitly.
```

---

## Step 2 — Publish

```
PICK THE ROUTE THAT MATCHES ROUND 6'S HOSTING ANSWER.

  ROUTE A — PUBLISH AS A HOSTED PAGE
    For a site that needs a shareable link now, with no infrastructure.
    □ Publish the built site; the entry document is index.html
    □ Multi-file: include every CSS, JS and asset at its served path
    □ Verify every internal link resolves on the published URL, not just
      locally — relative paths that work on disk can break when served
    □ Record the URL

  ROUTE B — STATIC HOST (Netlify, Vercel, Cloudflare Pages, GitHub Pages)
    The right default for a real multi-page site.
    □ Connect the repository, or deploy the directory
    □ Set the build command and publish directory (none and / for plain
      static)
    □ Configure clean URLs and the trailing-slash behaviour
    □ Add redirects for any .html paths if clean URLs are on
    □ Set the 404 page so it returns a real 404 status
    □ Add security headers: HSTS, X-Content-Type-Options,
      Referrer-Policy, and a Content-Security-Policy if the site's scripts
      allow one
    □ Enable asset compression (brotli) and long cache headers on
      fingerprinted assets
    □ Deploy to a PREVIEW URL first and re-run Check 1 against it

  ROUTE C — THE OWNER'S OWN HOSTING
    □ Produce the deployable directory and a README stating exactly what
      to upload where
    □ State the server requirements: none beyond static file serving
    □ Provide the rewrite rules for clean URLs for their server type

  DEPLOY VERIFICATION — on the live URL, not locally:
  □ Every page loads
  □ Every internal link resolves
  □ CSS and JS load (check the network panel for 404s)
  □ Fonts load from the right origin
  □ Images load, including the LCP image
  □ Forms submit to the real endpoint
  □ The artefact works
  □ Console clean
```

---

## Step 3 — Domain and HTTPS

```
  □ Domain registered and in the owner's own account, not anyone else's
  □ DNS records pointed at the host (A/AAAA or CNAME as the host requires)
  □ HTTPS certificate issued and valid
  □ HTTP redirects to HTTPS, 301
  □ ONE canonical host — pick www or apex, redirect the other, 301
  □ Canonical tags match the chosen host exactly
  □ No mixed content anywhere
  □ Propagation verified from more than one network

  □ Record: registrar · DNS host · canonical host · certificate expiry and
    whether renewal is automatic

  THE CANONICAL HOST DECISION MATTERS: serving on both www and apex without
  a redirect splits every ranking signal and makes analytics
  double-count. Pick one, now, and redirect.
```

---

## Step 4 — Analytics and Consent

```
  MEASUREMENT — wire what Round 3's metric actually needs, nothing more:
  □ The primary conversion fires an event. Test it and confirm it arrives.
  □ The secondary conversion fires an event
  □ Page views
  □ Outbound clicks on the primary CTA
  □ Scroll depth, if the page is long and that informs the next iteration
  □ A real-user Core Web Vitals collector (the web-vitals library) so the
    field numbers are known rather than guessed

  CONSENT — where Round 6 said it is required:
  □ Nothing non-essential loads before consent
  □ Decline is as easy as accept — one click, same prominence
  □ The choice persists and is re-changeable
  □ A link to the cookie policy
  □ Verify in a fresh profile that declining actually blocks the scripts

  PRIVACY-FIRST ALTERNATIVE worth offering:
  A cookieless analytics tool avoids the consent banner entirely in many
  jurisdictions, which removes the banner's conversion cost. Mention it;
  the owner decides.

  □ Test every event end to end. An analytics install nobody verified is
    an analytics install that is not working.
```

---

## Step 5 — Search

```
  □ Submit sitemap.xml to Google Search Console
  □ Submit to Bing Webmaster Tools
  □ Verify ownership
  □ Request indexing on the home page
  □ Confirm no manual actions or coverage errors
  □ Check the rendered page in the URL inspection tool — confirm the
    crawler sees the content, not an empty shell
  □ Confirm the OG image renders in a social debugger for at least one
    platform

  □ Record which pages were submitted and the date
```

---

## Step 6 — The Baseline

```
RECORD THE NUMBERS NOW, SO LATER CHANGES CAN BE JUDGED.

  AT LAUNCH:
    Lighthouse mobile: performance [N] · a11y [N] · best practices [N] ·
                       SEO [N]
    Lab LCP [N]s · INP [N]ms · CLS [N]
    Page weight: home [N]KB · heaviest page [N]KB
    Pages: [N] · Indexed: pending

  AT 28 DAYS — field data, which is what actually counts:
    CrUX / real-user LCP p75 [ ] · INP p75 [ ] · CLS p75 [ ]
    Passing all three: [ ]
    Sessions [ ] · Primary conversions [ ] · Conversion rate [ ]
    Top entry page [ ] · Top exit page [ ]
    Indexed pages [ ]

  Lab numbers and field numbers diverge. The gates in Step 7 are field
  thresholds measured at the 75th percentile, so the launch Lighthouse run
  is an indicator, not the verdict. Come back at 28 days.

  WHAT TO WATCH AND WHAT IT MEANS:
    Top exit page is not the thanks page → that page has a problem
    High scroll depth, low conversion   → the CTA is wrong or mistrusted
    Low scroll depth                    → the hero is not earning the scroll
    Field INP worse than lab            → the motion layer is too heavy on
                                          real devices
```

---

## Step 7 — Handover

```
WRITE HANDOVER.md FOR WHOEVER MAINTAINS THIS — ASSUME IT IS NOT YOU.

  CONTENTS:
  1. WHAT THIS IS — one paragraph: the site, the stack, where it is hosted
  2. HOW TO CHANGE COPY — the exact file and the exact line pattern, with
     one worked example of changing a headline
  3. HOW TO ADD A PAGE — copy which file, update which three places (nav,
     sitemap, footer)
  4. THE TOKEN FILE — "all colours, type and spacing live in
     css/tokens.css. Change a value there and it changes everywhere.
     Do not add values anywhere else."
  5. HOW TO ADD A SECTION — the available section templates and their
     classes
  6. THE MOTION RULES — "every effect has a reduced-motion fallback in
     motion.css. If you add an effect, add its fallback. Motion that
     cannot be disabled does not ship."
  7. WHAT NOT TO TOUCH — the artefact's fallback, the skip link, the
     image width/height attributes, the consent gate
  8. CLAIMS AND PERMISSIONS — the Round 4 table: every number, logo and
     testimonial, its source, its date, and its permission status. "Do not
     add a logo or testimonial that is not in this table."
  9. DEPLOY — how to publish a change, and how to roll back
 10. ACCOUNTS — what exists, in whose name (registrar, host, analytics,
     form endpoint). Credentials are NOT in this document.
 11. WHEN TO RE-AUDIT — "re-run Step 7 after any change to the motion
     layer, the hero, or any claim."

  □ Written for someone who did not build it
  □ No credentials, no API keys, no tokens in the document
  □ Includes the date and who to ask
```

---

## Step 8 — Archive and Carry Forward

```
ARCHIVE CONTENTS:
  □ site_brief.md · site_map.md · site_copy.md · design_system.md
  □ motion_spec.md · build_log.md · quality_report.md · publish_log.md
  □ BRAND_VOICE.md
  □ The full built site as deployed
  □ HANDOVER.md
  □ Source assets — design files, original images, video masters

CARRY FORWARD — this is what makes the next site faster, and it compounds:
  □ tokens.css                 the token architecture, re-themed per project
  □ The component CSS          button, card, nav, accordion, form — these
                               barely change between projects
  □ motion.css                 the reduced-motion scaffolding and the
                               reveal system, already accessible
  □ The reduced-motion matrix  a template; the effects repeat
  □ The section template set   hero, split, three-up, stat row, logo wall,
                               quote, pricing, FAQ, closing CTA
  □ The grill question set     Step 1's seven rounds, refined by what you
                               wished you had asked this time
  □ The reference library      the studied sites and what each does well
  □ The audit checklist        with any failure you hit this time added

  THE GRILL IMPROVES WITH USE:
  After each site, add the question you wished you had asked in Round 1-7.
  The brief is the part of this pipeline that compounds hardest, because a
  better question up front saves a rebuild later.
  Question to add next time: [...]

EDITION LABEL:
  Increment in post-launch records: "Launched 1.0" → "1.1" → "2.0"
```

---

## Output File: publish_log.md

```markdown
# Publish Log
Pipeline step: 8 of 8
Date: [date]
Reads: quality_report.md, build_log.md, site_brief.md

---

## Pre-Ship
Eight checks: [ALL PASS / blockers]
Placeholder grep: [N] · Secrets grep: [N] · robots.txt: [production]
SHIP READY: [YES / NO]

---

## Published
Route: [A hosted page / B static host / C own hosting]
Live URL: [...]
Preview verified before domain switch: [yes]

Deploy verification:
| Page | Loads | Links | CSS/JS | Images | Console |
|------|-------|-------|--------|--------|---------|

---

## Domain
Registrar: [...] · DNS: [...] · Canonical host: [www / apex]
HTTPS: [valid, expires [date], auto-renew [yes/no]]
HTTP→HTTPS 301: [yes] · Non-canonical→canonical 301: [yes]
Mixed content: [none]

---

## Analytics and Consent
Tool: [...] · Events wired: [list] · Each verified: [N]/[N]
Web-vitals collector: [yes/no]
Consent required: [yes/no] · Non-essential blocked before consent: [verified]

---

## Search
Sitemap submitted: [GSC date] · [Bing date]
Pages submitted: [N] · Rendered correctly in inspection: [yes]
OG image renders: [verified on [platform]]

---

## Baseline — at launch
Lighthouse mobile: perf [N] · a11y [N] · BP [N] · SEO [N]
Lab: LCP [N]s · INP [N]ms · CLS [N]
Weight: home [N]KB · heaviest [N]KB

## Baseline — at 28 days (fill later)
Field p75: LCP [ ] · INP [ ] · CLS [ ] · passing all three [ ]
Sessions [ ] · Conversions [ ] · Rate [ ]
Top entry [ ] · Top exit [ ] · Indexed [ ]

---

## Handover
HANDOVER.md written: [yes] · Sections: 11
Maintainer: [...] · Contains credentials: [NO — required]

---

## Archive
Artefacts: [N] · Location: [...]
Carry forward: tokens.css · component CSS · motion.css + matrix ·
section templates · the grill question set · reference library ·
audit checklist
Question to add to the grill next time: [...]

---

## Pipeline Complete
Step 1 ✅ site-brief     → site_brief.md
Step 2 ✅ site-architect → site_map.md
Step 3 ✅ site-copy      → site_copy.md
Step 4 ✅ site-design    → design_system.md
Step 5 ✅ site-motion    → motion_spec.md
Step 6 ✅ site-build     → build_log.md
Step 7 ✅ site-audit     → quality_report.md
Step 8 ✅ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `publish_log.md`, present this EXACTLY:

```
✅ Shipped. Saved to publish_log.md.

🌐 Live: [URL]

📋 Final state:
- Pages        : [N]
- Route        : [A/B/C] — [host]
- Domain       : [canonical host], HTTPS valid to [date]
- Analytics    : [tool], [N] events verified
- Sitemap      : submitted [date], [N] pages
- Quality      : 8/8 checks pass

Launch baseline:
  Lighthouse mobile : perf [N] · a11y [N] · SEO [N]
  Lab LCP [N]s · INP [N]ms · CLS [N]
  Home page weight  : [N]KB

Pre-ship sweep:
  Placeholders [N] · Secrets [N] · robots.txt [production] · favicon [real]

📄 HANDOVER.md written — how to change copy, add a page, add a section,
and the claims table with every permission recorded. No credentials in it.

🗄️ Archived: [N] artefacts.
Carry forward to the next site: tokens.css, the component CSS, the motion
scaffolding and its reduced-motion matrix, the section templates, and the
grill question set.

⏰ Come back at 28 days for the field numbers. Lab Lighthouse is an
indicator; the gates are field thresholds at the 75th percentile, so the
real verdict arrives with real traffic.

👉 The pipeline is complete. You can:
  - Log the baseline → say "baseline: [numbers]"
  - Change something → say "back to copy for [page]"
  - Add a page → say "add a [page] page"
  - Start another site → say "new site brief"
  - Improve the grill → say "add [question] to Round [N]"

✅ Motion Site Engine Pipeline complete.
```

**NEVER** ship with a FAIL in quality_report.md.

**NEVER** leave a staging robots.txt or a test analytics ID in a live deploy.

**NEVER** put credentials in HANDOVER.md.

Approval keywords: `done`, `complete`, `new site brief`,
`baseline`, `add a page`
