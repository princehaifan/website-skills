---
name: site-design
description: >
  Step 4 of 8 in the Motion Site Engine Pipeline. Takes site_brief.md,
  site_map.md and site_copy.md and builds the design system: colour with
  verified contrast, a type scale, spacing and grid, radius, elevation,
  border and surface tokens, dark mode, and a component spec for every
  element the copy requires. Everything is a CSS custom property so Step 6
  writes no raw values. Saves as design_system.md.
---

# Site Design

A design system is not a mood board.
It is the set of decisions you refuse to make again on every section.
Pick the type scale once. Pick the eight spacing values once.
Pick the four surfaces once. Then the build is assembly, not invention.
If a value appears twice in the build, it belonged here.
Save as `design_system.md`.

---

## The Token Rule

```
EVERY VISUAL VALUE IS A TOKEN. STEP 6 WRITES NO RAW HEX, NO RAW PX.

  WHY THIS IS NOT PEDANTRY:
  A site built from raw values cannot have a dark mode added, cannot be
  rebranded, and drifts section by section until the twelfth block has its
  own grey. The reference sites that feel expensive feel that way because
  they are built from a small set of values used consistently, not from a
  large set of values used once.

  THE BUDGET — exceed these and the system is not a system:
    Colours        ≤ 12 semantic tokens (from ≤ 5 raw hues)
    Type sizes     ≤ 8
    Font weights   ≤ 3
    Spacing values ≤ 8
    Radii          ≤ 4
    Shadows        ≤ 4
    Breakpoints    ≤ 4
    Durations      ≤ 4 (Step 5 owns these)
    Easings        ≤ 3 (Step 5 owns these)

  WHERE THE OWNER HAS A SAVED DESIGN SYSTEM:
  Round 5 recorded whether to follow, extend or depart from it. Follow that
  decision exactly. If following, this step maps the existing system onto
  the token names below rather than inventing new values — and says in the
  gate that it did so.

THE RULE:
  Never introduce a value outside the token set during the build.
  Never ship a contrast ratio below the gate without recording the
  exception and its reason.
  Never set a type size in px for body copy.
  Never use colour as the only carrier of meaning.
```

---

## Step 1 — Colour

```
BUILD FROM FIVE RAW HUES AT MOST, THEN NAME THEM SEMANTICALLY.

  RAW RAMPS (generate 50-950 for each):
    brand      [hex] — the one colour the site is remembered by
    neutral    [hex] — text, borders, surfaces. Usually a slightly warm or
                       cool grey, never pure #808080
    accent     [hex] — optional second colour for highlight and data
    success    [hex]
    danger     [hex]

  SEMANTIC TOKENS (what the build actually uses):
    --bg               page background
    --bg-subtle        alternating section background
    --bg-raised        card surface
    --bg-inset         input and well surface
    --text             body text
    --text-muted       secondary text, captions
    --text-inverse     text on brand fills
    --border           default border
    --border-strong    emphasised border, focus ring base
    --brand            primary fill
    --brand-hover      primary fill, hover
    --brand-text       text on brand

  THE FOUR-SURFACE RULE:
  Decide --bg, --bg-subtle, --bg-raised, --bg-inset once. Every section
  background is one of these four. Sections alternate between --bg and
  --bg-subtle to create rhythm without introducing new colours. This single
  decision does more for coherence than any other.

  CONTRAST GATES — compute each ratio, do not estimate:
    --text on --bg             ≥ 7.0:1   (AAA body, the target)
    --text on --bg-subtle      ≥ 7.0:1
    --text-muted on --bg       ≥ 4.5:1   (AA minimum, never below)
    --brand-text on --brand    ≥ 4.5:1
    Large text (≥24px or ≥19px bold) ≥ 3.0:1
    UI borders and icons       ≥ 3.0:1
    Focus ring on every surface it appears on ≥ 3.0:1

  □ Record the computed ratio for every pair above
  □ Any pair below its gate: change the colour, do not lower the gate
  □ Never rely on hue alone — every state carries an icon, a weight change
    or a label as well as a colour

  DARK MODE (if Round 5 said both):
  □ Not an inversion. --bg in dark is a dark grey, never #000
  □ Brand colour usually needs lightening in dark to hold contrast
  □ Shadows barely read on dark — use a lighter border instead
  □ Recompute every contrast ratio for the dark set
  □ Implement as [data-theme="dark"] plus a prefers-color-scheme default
```

---

## Step 2 — Type

```
TWO FAMILIES MAXIMUM. THREE WEIGHTS MAXIMUM.

  FAMILIES:
    --font-display   headings. Where the site's character lives.
    --font-body      body. Chosen for reading, not for personality.
    --font-mono      optional, for code, data and labels
  □ One family doing both is a legitimate and often better choice
  □ Every family has a system fallback stack behind it
  □ Self-host or use font-display: swap — a blocking font request is the
    most common LCP failure on a well-designed site

  SCALE — a ratio, not arbitrary numbers. 1.25 for calm, 1.333 for
  editorial, 1.5 for dramatic. Pick one and generate:
    --text-xs    [N]rem
    --text-sm    [N]rem
    --text-base  1rem      ← body, always 16px minimum
    --text-lg    [N]rem
    --text-xl    [N]rem
    --text-2xl   [N]rem
    --text-3xl   [N]rem
    --text-4xl   [N]rem    ← hero

  FLUID TYPE for display sizes:
    --text-4xl: clamp([min]rem, [N]vw + [N]rem, [max]rem);
  □ Hero headline fluid between mobile and desktop
  □ Body size NOT fluid — it should be 16-18px everywhere
  □ Never below 16px for body text on mobile; iOS zooms on focus below that

  LINE HEIGHT AND MEASURE:
    --leading-tight   1.1   display
    --leading-snug    1.3   subheads
    --leading-normal  1.6   body
  □ Body measure 60-75 characters. Set --measure: 65ch and use it.
  □ Headings get negative tracking at display sizes: -0.02em to -0.04em
  □ Body gets no tracking adjustment

  WEIGHTS: pick three, e.g. 400 body / 600 subhead / 800 display
  □ Never synthesise bold — load the weight or do not use it
```

---

## Step 3 — Spacing and Grid

```
ONE SPACING SCALE. EIGHT VALUES. EVERYTHING SNAPS TO IT.

    --space-1   0.25rem
    --space-2   0.5rem
    --space-3   0.75rem
    --space-4   1rem
    --space-6   1.5rem
    --space-8   2rem
    --space-12  3rem
    --space-16  4rem
  Plus two section-scale values:
    --space-section       clamp(4rem, 8vw, 8rem)
    --space-section-tight clamp(3rem, 5vw, 5rem)

  □ Vertical rhythm between sections is ONE of the two section values
  □ A gap not on the scale is a bug

  GRID:
    --container       1200px (or 1280px)
    --container-text  720px   ← prose never full-width
    --gutter          clamp(1rem, 4vw, 2rem)
    Columns: 12 on desktop, 6 on tablet, 4 on mobile
  □ Full-bleed sections still constrain their content to --container
  □ A text block wider than --container-text is unreadable regardless of
    how good the type is

  BREAKPOINTS — four, mobile-first:
    sm 640px · md 768px · lg 1024px · xl 1280px
  □ Design mobile first and genuinely, not by shrinking the desktop layout
  □ Test at 320px — it still exists and it is where layouts break

  RADIUS AND ELEVATION:
    --radius-sm / --radius-md / --radius-lg / --radius-full
    --shadow-sm / --shadow-md / --shadow-lg / --shadow-glow
  □ Radius is a brand signal: sharp reads technical, round reads friendly.
    Pick a position and hold it.
  □ Shadows tinted with the neutral hue, never pure black at opacity
```

---

## Step 4 — Component Spec

```
SPEC EVERY COMPONENT site_copy.md REQUIRES. NOTHING MORE.
Walk the copy file; each distinct element gets an entry.

  PER COMPONENT, SPECIFY:
    Anatomy · tokens used · every state · responsive behaviour ·
    accessibility requirement

  THE STATE SET — every interactive component needs all seven:
    default · hover · active · focus-visible · disabled · loading · error

  FOCUS IS NOT OPTIONAL:
  □ Every interactive element has a visible focus-visible ring
  □ 2px minimum, 2px offset, ≥3:1 against its background
  □ Never `outline: none` without a replacement that meets the gate
  □ Focus order follows DOM order; DOM order follows reading order

  THE LIKELY SET — spec those the copy needs:
    Button        primary / secondary / ghost · sm / md / lg · with-icon ·
                  loading. Min target 44×44px.
    Link          inline (underlined) / nav / footer
    Nav           desktop bar · mobile drawer · sticky behaviour
    Card          feature / case-study / pricing-tier / testimonial
    Logo wall     grid, greyscale-to-colour on hover, responsive wrap
    Stat block    number · unit · label
    Accordion     FAQ. Keyboard-operable, one open or many.
    Tabs          if the artefact needs them. Arrow-key navigation.
    Form field    label · input · helper · error · required marker
    Toggle        theme switch, pricing period switch
    Table         pricing comparison. Scrollable on mobile with a visible
                  affordance, not a silent overflow.
    Badge / pill  eyebrows, "recommended", changelog tags
    Footer        column layout, responsive collapse

  RESPONSIVE BEHAVIOUR IS PART OF THE SPEC:
  □ State what each component does at each breakpoint
  □ "Cards: 3-up at lg, 2-up at md, 1-up below" — written, not discovered
```

---

## Step 5 — Section Templates

```
SPEC THE RECURRING SECTION SHELLS SO THE BUILD IS ASSEMBLY.

  FOR EACH TEMPLATE: background token · padding · container · content grid
  · heading size · max text width

    HERO            --bg · --space-section ×1.5 · content 60/40 split at lg
    SPLIT           --bg or --bg-subtle · text one side, visual the other,
                    alternating sides down the page
    THREE-UP        --bg-subtle · 3 cards at lg, 1 at sm
    FULL-BLEED      --bg-raised · edge-to-edge visual, content overlaid
    STAT ROW        --bg · 3-4 columns, centred
    LOGO WALL       --bg-subtle · auto-fit grid, min 120px
    QUOTE           --bg-raised · narrow, centred, --container-text
    PRICING         --bg · tiers side by side, recommended raised
    FAQ             --bg-subtle · accordion at --container-text
    CLOSING CTA     --brand or --bg-raised · centred, generous padding

  THE ALTERNATION RULE:
  Walk the section list from site_map.md and assign backgrounds so no two
  adjacent sections share one. This is what stops a long page reading as
  undifferentiated scroll.
  □ Record the assignment: section 1 --bg, 2 --bg-subtle, 3 --bg, ...
  □ Never three consecutive sections on the same surface
```

---

## Step 6 — The Token File

```
OUTPUT A COMPLETE, PASTEABLE tokens.css. STEP 6 IMPORTS IT AND ADDS NOTHING.

```css
:root {
  /* colour — raw */
  --brand-500: #______;
  --neutral-50: #______;
  /* ...full ramps... */

  /* colour — semantic */
  --bg: var(--neutral-50);
  --bg-subtle: var(--neutral-100);
  --bg-raised: #ffffff;
  --bg-inset: var(--neutral-100);
  --text: var(--neutral-900);
  --text-muted: var(--neutral-600);
  --border: var(--neutral-200);
  --brand: var(--brand-600);
  --brand-hover: var(--brand-700);
  --brand-text: #ffffff;

  /* type */
  --font-display: ______, system-ui, sans-serif;
  --font-body: ______, system-ui, sans-serif;
  --text-base: 1rem;
  --text-4xl: clamp(______);
  --leading-normal: 1.6;
  --measure: 65ch;

  /* space */
  --space-4: 1rem;
  --space-section: clamp(4rem, 8vw, 8rem);

  /* layout */
  --container: 1200px;
  --container-text: 720px;
  --gutter: clamp(1rem, 4vw, 2rem);

  /* shape */
  --radius-md: ______;
  --shadow-md: ______;

  /* focus */
  --focus-ring: 2px solid var(--brand);
  --focus-offset: 2px;
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) { /* dark overrides */ }
}
[data-theme="dark"] { /* same overrides */ }
```

  □ Every token in the budget present
  □ No raw value appears outside :root
  □ Dark overrides only redefine semantic tokens, never raw ramps
```

---

## Output File: design_system.md

```markdown
# Design System
Pipeline step: 4 of 8
Date: [date]
Reads: site_brief.md, site_map.md, site_copy.md

---

## Source
Existing system: [followed / extended / departed from / none]
[If following: which, and what was mapped]

---

## Colour

Raw hues: [N]
| Token | Value | Role |
|-------|-------|------|

### Contrast audit
| Pair | Ratio | Gate | Verdict |
|------|-------|------|---------|
| --text on --bg | [N]:1 | 7.0 | [PASS/FAIL] |

Dark mode: [yes/no] · dark ratios: [all PASS / list]
Exceptions recorded: [none / list with reason]

---

## Type
Families: [display] / [body] / [mono]
Scale ratio: [N] · Sizes: [N] · Weights: [N]
Fluid: [which sizes]
Measure: [N]ch · Loading: [self-host / swap]

---

## Spacing and Grid
Spacing values: [N] · Section rhythm: [values]
Container: [N] · Text container: [N] · Breakpoints: [N]
Radius: [N] · Shadows: [N]

---

## Components
| Component | Variants | States specced | Min target | Responsive |
|-----------|----------|----------------|------------|------------|

Components: [N] · All 7 states: [N]/[N] · Focus ring on all: [PASS/FAIL]

---

## Section Templates
| Template | Background | Padding | Grid |
|----------|------------|---------|------|

Background alternation (home): [1 --bg, 2 --bg-subtle, ...]
Runs of 3 same surface: [none / list]

---

## tokens.css
```css
[complete file]
```

Token budget:
| Category | Used | Budget | OK |
|----------|------|--------|-----|
| Colours (semantic) | [N] | 12 | [✓] |
| Type sizes | [N] | 8 | [✓] |
| Weights | [N] | 3 | [✓] |
| Spacing | [N] | 8 | [✓] |
| Radii | [N] | 4 | [✓] |
| Shadows | [N] | 4 | [✓] |

---

## Pipeline Status
Step 1 ✅ site-brief     → site_brief.md
Step 2 ✅ site-architect → site_map.md
Step 3 ✅ site-copy      → site_copy.md
Step 4 ✅ site-design    → design_system.md
Step 5 ⬜ site-motion    → motion_spec.md
Step 6 ⬜ site-build     → build_log.md
Step 7 ⬜ site-audit     → quality_report.md
Step 8 ⬜ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `design_system.md`, present this EXACTLY:

```
✅ Design system complete. Saved to design_system.md.

📋 Summary:
- Source      : [existing system followed / extended / new]
- Colours     : [N] semantic tokens from [N] raw hues
- Type        : [N] families, [N] sizes, ratio [N], [N] weights
- Spacing     : [N] values · Breakpoints: [N]
- Components  : [N] specced, all 7 states each
- Dark mode   : [yes / no]

Contrast audit:
  --text on --bg          : [N]:1  (gate 7.0) [PASS/FAIL]
  --text-muted on --bg    : [N]:1  (gate 4.5) [PASS/FAIL]
  --brand-text on --brand : [N]:1  (gate 4.5) [PASS/FAIL]
  Focus ring              : [N]:1  (gate 3.0) [PASS/FAIL]
  [dark mode rows if applicable]

Token budget: [N]/[N] categories within budget
Surface alternation: [N] sections, [0] runs of three

[IF any contrast FAIL] 🛑 [N] pairs below gate: [list]. Colour changed
rather than the gate lowered — here is what moved: [list].

👉 Review design_system.md. You can:
  - Approve → say "approved" or "spec the motion"
  - Change the brand colour → say "brand is [hex]"
  - Change the type → say "use [font] for headings"
  - Tighten the scale → say "ratio [N]"
  - Add dark mode → say "add dark mode"
  - Adjust a component → say "buttons should be [change]"

⏸️ Waiting for approval before Motion runs.
```

**NEVER** proceed automatically.

**NEVER** lower a contrast gate to make a colour pass.

Approval keywords: `approved`, `spec the motion`, `motion`,
`proceed`, `next`, `go`, `looks good`, `design approved`
