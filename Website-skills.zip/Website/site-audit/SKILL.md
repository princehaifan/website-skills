---
name: site-audit
description: >
  Step 7 of 8 in the Motion Site Engine Pipeline. Takes build_log.md and runs
  the full quality suite: Core Web Vitals against verified thresholds,
  accessibility to WCAG AA plus the motion criteria, responsive behaviour from
  320px up, motion safety, copy and claim integrity, SEO and crawlability, and
  cross-browser checks. Every FAIL is a blocker. Nothing ships with an
  uncontrolled animation or an unverified claim. Saves as quality_report.md.
---

# Site Audit

A site that looks finished in a browser window is not a finished site.
The build says: it renders.
The audit says: does it load, does it work without a mouse,
does it stay still for someone it would otherwise make ill,
and is every word on it true.
Run every check. Fix what fails. Do not ship what you would not defend.
Save as `quality_report.md`.

---

## The Eight Checks

```
CHECK 1 — PERFORMANCE          Core Web Vitals and weight budgets
CHECK 2 — ACCESSIBILITY        WCAG 2.2 AA, keyboard, screen reader
CHECK 3 — MOTION SAFETY        reduced motion, pause controls, vestibular
CHECK 4 — RESPONSIVE           320px to 1920px, touch, orientation
CHECK 5 — CONTENT INTEGRITY    every claim traced, no placeholders
CHECK 6 — SEO AND CRAWL        head tags, sitemap, structured data, links
CHECK 7 — ROBUSTNESS           no JS, slow network, cross-browser, errors
CHECK 8 — CONVERSION           the spine works end to end

THE RULE:
  A FAIL is a blocker, not a note. Fix it or cut the feature that causes it.
  A tier-4 effect that fails the performance gate gets cut — the gate does
  not move.
  An audit that passes everything first time was not an audit.
```

---

## Check 1 — Performance

```
THE VERIFIED THRESHOLDS. Core Web Vitals are three field metrics assessed
at the 75th percentile of real visits: 75% of visits must clear each bar,
and all three must pass together.

  | Metric | Good | Needs improvement | Poor |
  |--------|------|-------------------|------|
  | LCP    | ≤2.5s | 2.5-4.0s | >4.0s |
  | INP    | ≤200ms | 200-500ms | >500ms |
  | CLS    | ≤0.1 | 0.1-0.25 | >0.25 |

  SUPPORTING TARGETS:
  | FCP | ≤1.8s | · | TBT | ≤200ms | · | Lighthouse | ≥90 |

  For context on how hard this is: as of May 2026 CrUX data, 55.9% of
  tracked origins pass all three, and mobile LCP is the hardest of the
  three at 62% good against 81% for CLS. A motion-heavy site that passes
  is genuinely above the field.

  MEASURE, DO NOT ESTIMATE:
  □ Lighthouse on mobile preset, 4× CPU throttle, Slow 4G
  □ Run three times, take the median — single runs vary
  □ Record each metric's value, not just pass/fail

  WEIGHT BUDGETS:
    HTML per page      ≤ 50KB
    CSS total          ≤ 60KB gzipped
    JS total           ≤ motion-tier budget from Step 5
    Largest image      ≤ 200KB
    Fonts              ≤ 120KB total
    Home page total    ≤ 1.2MB (tier 1-3) · ≤ 2.5MB (tier 4, lazy)

  THE USUAL CULPRITS, IN ORDER OF FREQUENCY:
  □ LCP: hero image not preloaded, or animated from opacity:0, or a
    blocking font request
  □ CLS: image without width/height, a font swap without metric matching,
    an element injected above existing content
  □ INP: a long task from the motion library on load, or a scroll handler
  □ TBT: an animation library parsed before first paint

  □ If a tier-4 asset breaks LCP: lazy-load it behind first paint. If it
    still breaks, cut the effect.
```

---

## Check 2 — Accessibility

```
WCAG 2.2 LEVEL AA IS THE BAR. AA IS NOT OPTIONAL POLISH.

  AUTOMATED FIRST, THEN MANUAL. Automated tools catch about a third.
  □ axe or Lighthouse a11y: 0 violations
  □ Record the tool and version

  STRUCTURE:
  □ One h1 per page, no skipped levels
  □ Landmarks present: header, nav, main, footer
  □ Skip link first in DOM, visible on focus, lands on #main
  □ lang attribute correct on <html>
  □ Page <title> unique and descriptive

  KEYBOARD — the whole site, mouse unplugged:
  □ Every interactive element reachable by Tab
  □ Focus visible at every stop, ≥3:1 contrast, 2px minimum
  □ Focus order matches visual order on every page
  □ No keyboard trap anywhere — especially in the artefact and the drawer
  □ Mobile drawer: Escape closes it, focus returns to the trigger
  □ Accordion operable with Enter and Space
  □ The interactive artefact fully operable, per its specified path
  □ Skip link is the first stop

  SCREEN READER — test with one, do not assume:
  □ Every image's alt conveys its information
  □ Decorative images alt=""
  □ Buttons have accessible names (visible text, or aria-label)
  □ Form fields have programmatic labels
  □ Errors announced via a live region
  □ The artefact's output announced when it changes
  □ Icon-only buttons labelled
  □ No "click here" or "read more" as the entire link text

  COLOUR AND CONTRAST — re-verify against the built site, not the spec:
  □ Body text ≥4.5:1 (target 7:1)
  □ Large text ≥3:1
  □ UI components and focus rings ≥3:1
  □ No information carried by colour alone
  □ Test at 200% zoom and 400% zoom — content reflows, nothing clipped
  □ Text spacing override test: line-height 1.5, letter-spacing 0.12em,
    word-spacing 0.16em, paragraph-spacing 2em — nothing breaks

  TARGETS AND INPUT (WCAG 2.2 additions):
  □ Target size ≥24×24px minimum (44×44 recommended and used here)
  □ Dragging movements have a single-pointer alternative — this applies
    directly to a drag-based artefact
  □ Focus not obscured by sticky headers when tabbing
```

---

## Check 3 — Motion Safety

```
THE CHECK THE REST OF THE INDUSTRY SKIPS.

  REDUCED MOTION — turn the OS setting on, then walk every page:
  | # | Effect | Spec'd fallback | Actual | Verdict |
  |---|--------|-----------------|--------|---------|

  □ Every row in the Step 5 matrix verified in the browser
  □ No element stuck at opacity:0 or mid-transform
  □ No content hidden because its reveal never fired
  □ Mid-visit flip of the OS setting stops running animations
  □ Smooth scrolling disabled under reduced motion
  □ The artefact still fully functional, just not animated

  PAGE-INITIATED MOTION (SC 2.2.2 Pause, Stop, Hide — Level A):
  Motion the page starts, rather than motion the user triggers, is a Level
  A obligation. Anything moving, blinking or scrolling automatically for
  more than five seconds needs a pause, stop or hide control.
  | Element | Auto-starts | >5s | Control present | Keyboard-reachable |
  |---------|-------------|-----|-----------------|--------------------|
  □ Hero video loop: control present and labelled
  □ Logo marquee: pausable by keyboard, not hover only
  □ Any carousel: pausable, and not auto-advancing under reduced motion

  INTERACTION-TRIGGERED MOTION (SC 2.3.3 — Level AAA):
  Motion triggered by interaction must be disableable unless essential.
  Parallax on scroll and click-triggered animation are named explicitly.
  □ All parallax disabled under reduced motion
  □ All page transitions disabled under reduced motion
  □ Scroll-linked sequences unpinned under reduced motion

  VESTIBULAR SAFETY — beyond the letter of the criteria:
  □ No effect translates an element further than its own height
  □ No full-screen zoom or rotate transitions
  □ No parallax factor above 0.3
  □ Nothing flashes more than 3 times per second (SC 2.3.1, Level A —
    this one is a hard safety floor, not a preference)
  □ No motion in the periphery while the centre is being read

  □ ANY FAIL HERE IS A SHIP BLOCKER. Motion that cannot be turned off is
    the one defect on this list that can physically harm a visitor.
```

---

## Check 4 — Responsive

```
TEST AT REAL WIDTHS, ON A REAL DEVICE WHERE POSSIBLE.

  WIDTHS: 320 · 360 · 390 · 414 · 768 · 1024 · 1280 · 1440 · 1920
  | Width | Overflow | Nav | Hero | Cards | Table | Artefact | Verdict |
  |-------|----------|-----|------|-------|-------|----------|---------|

  □ Zero horizontal overflow at every width — verify with
    document.documentElement.scrollWidth vs window.innerWidth
  □ 320px works. It is the floor and it is where things break.
  □ Nav drawer opens, closes, traps nothing
  □ Hero headline does not orphan a single word on its last line
  □ Pricing table scrolls with a visible affordance, not silently
  □ Artefact degrades as specified below 640px
  □ No fixed heights clipping text at any width
  □ Tap targets ≥44px and not overlapping
  □ Landscape on a phone (short viewport) — sticky nav does not eat the
    screen; 100vh sections do not trap content
  □ Dynamic viewport units where a mobile browser chrome shift matters
    (dvh rather than vh for full-height sections)
```

---

## Check 5 — Content Integrity

```
EVERY WORD ON THE BUILT SITE, AGAINST site_copy.md AND ROUND 4.

  PLACEHOLDER SWEEP — grep the whole build:
  □ "lorem" · "ipsum" · "TODO" · "FIXME" · "placeholder" · "Lorem"
  □ "[" and "]" in rendered text (unreplaced template markers)
  □ "example.com" · "your-domain" · "John Doe" · "Jane Smith"
  □ Stock testimonial names
  □ Default favicon
  Found: [N] → must be 0

  CLAIM TRACEABILITY:
  | Claim on site | Page | Round 4 source | Permission | Verdict |
  |---------------|------|----------------|------------|---------|
  □ Every number traced to a Round 4 item with a date
  □ Every logo traced to written permission
  □ Every testimonial traced to approved wording and a real person
  □ Every certification named exactly, and actually held
  □ ❌ UNTRACED count must be 0

  THE THREE THAT END CAREERS:
  □ A logo used without permission
  □ A testimonial that was written by the site's author
  □ A certification claimed that is not held
  Any of these: remove immediately, regardless of how the section looks
  afterwards.

  COPY QA:
  □ Spellcheck, in the right locale
  □ Primary CTA label identical in every placement: [N] placements, [N]
    distinct labels (must be 1)
  □ No two pages share a <title> or meta description
  □ Every internal link resolves — zero 404s
  □ Every external link resolves and opens appropriately
  □ Prices and dates current
  □ Legal pages present and not placeholder text
```

---

## Check 6 — SEO and Crawl

```
  PER PAGE:
  □ <title> 50-60 chars, unique
  □ meta description 140-160 chars, unique
  □ canonical, absolute, self-referencing
  □ OG title, description, image — image is absolute and ≥1200×630
  □ Twitter card renders — test it
  □ JSON-LD validates with no errors

  SITE:
  □ sitemap.xml lists every indexable page, absolute URLs, zero 404s
  □ robots.txt points at the sitemap, blocks nothing it should not
  □ No noindex left on a page that should be indexed
  □ One canonical host — www or apex, with the other redirecting
  □ HTTPS throughout, no mixed content
  □ Clean URLs working, with the .html variants redirecting if they exist
  □ 404 page returns an actual 404 status, not 200
  □ Images have alt text (also an a11y check — both matter here)
  □ Heading hierarchy coherent per page

  □ Validate the HTML. Not for a badge — for the parse errors that break
    screen readers and crawlers.
```

---

## Check 7 — Robustness

```
  NO JAVASCRIPT:
  □ Every page readable and navigable
  □ Nav usable
  □ FAQ expandable (details/summary survives)
  □ Forms submit
  □ Artefact shows its static fallback
  □ No blank sections, no invisible content

  SLOW AND FLAKY:
  □ Slow 4G: usable before fully loaded
  □ Fonts failing: fallback stack readable, layout not destroyed
  □ Images failing: alt text visible, layout holds
  □ The artefact's endpoint failing: failure state shows, not a broken box

  CROSS-BROWSER — current Chrome, Safari, Firefox, plus iOS Safari and
  Chrome Android:
  | Browser | Layout | Motion | Artefact | Forms | Verdict |
  |---------|--------|--------|----------|-------|---------|
  □ Safari specifically: backdrop-filter, scroll-driven animations, dvh,
    and :has() behave differently — check each if used
  □ iOS Safari: 100vh, form zoom on inputs under 16px, momentum scroll

  CONSOLE:
  □ Zero errors on every page
  □ Zero warnings that indicate a real problem
  □ No console.log left in
  □ No 404s in the network panel
```

---

## Check 8 — Conversion

```
WALK THE SPINE FROM site_map.md AS A VISITOR WOULD.

  □ Land on the home page. Is the primary CTA visible without scrolling?
  □ Click it. Does it do what the label promised?
  □ Complete the primary conversion end to end. Does the success state
    confirm what happened and name the next step?
  □ Complete the secondary conversion.
  □ On mobile: is the primary CTA reachable without opening the nav drawer?
  □ Does the arrival objection from Round 2 get answered before the first
    CTA a visitor is likely to reach?
  □ Does every page offer a route onward? No dead ends.
  □ Is the email capture actually capturing — test with a real address and
    confirm it arrives?

  □ Any integration that is stubbed rather than wired: listed here plainly
    so it is not mistaken for working.
```

---

## Output File: quality_report.md

```markdown
# Quality Report
Pipeline step: 7 of 8
Date: [date]
Reads: build_log.md, motion_spec.md, design_system.md, site_copy.md, site_brief.md

---

## Check 1: Performance
Tool: [Lighthouse vN], mobile preset, 4× CPU, Slow 4G, median of 3

| Page | LCP | INP | CLS | FCP | TBT | LH | Verdict |
|------|-----|-----|-----|-----|-----|----|---------|
Gates: LCP ≤2.5s · INP ≤200ms · CLS ≤0.1 · FCP ≤1.8s · TBT ≤200ms · LH ≥90

Weight: HTML [N]KB · CSS [N]KB · JS [N]KB · largest image [N]KB · total [N]KB
Verdict: [PASS/FAIL]

## Check 2: Accessibility
axe violations: [N] (must be 0)
Keyboard: [PASS/FAIL] · Screen reader: [PASS/FAIL]
Contrast re-verified: [N]/[N] pairs · 200%/400% zoom: [PASS/FAIL]
Text-spacing override: [PASS/FAIL] · Target size: [PASS/FAIL]
Verdict: [PASS/FAIL]

## Check 3: Motion Safety
| # | Effect | Spec'd fallback | Actual | Verdict |
|---|--------|-----------------|--------|---------|

Reduced-motion verified: [N]/[N]
Page-initiated with controls (2.2.2): [N]/[N]
Parallax disabled: [PASS] · Flash ≤3Hz: [PASS]
Verdict: [PASS/FAIL]

## Check 4: Responsive
| Width | Overflow | Nav | Hero | Cards | Table | Artefact | Verdict |
|-------|----------|-----|------|-------|-------|----------|---------|
Verdict: [PASS/FAIL]

## Check 5: Content Integrity
Placeholders found: [N] (must be 0)
| Claim | Page | Source | Permission | Verdict |
|-------|------|--------|------------|---------|
Untraced claims: [N] · CTA labels distinct: [N] (must be 1)
Broken links: [N] · Duplicate meta: [N]
Verdict: [PASS/FAIL]

## Check 6: SEO and Crawl
Per-page head tags: [N]/[N] complete · JSON-LD valid: [N]/[N]
Sitemap: [N] URLs, [N] 404s · 404 returns 404: [yes]
HTML validation: [N] errors
Verdict: [PASS/FAIL]

## Check 7: Robustness
No-JS: [PASS/FAIL] · Slow 4G: [PASS/FAIL] · Font fail: [PASS/FAIL]
| Browser | Layout | Motion | Artefact | Forms | Verdict |
|---------|--------|--------|----------|-------|---------|
Console errors: [N] (must be 0)
Verdict: [PASS/FAIL]

## Check 8: Conversion
Primary flow end to end: [PASS/FAIL]
Secondary flow: [PASS/FAIL]
CTA above fold on mobile: [yes/no]
Objection answered before first CTA: [yes/no]
Dead-end pages: [N]
Stubbed integrations: [list]
Verdict: [PASS/FAIL]

---

## Final Status
| Check | Verdict | Blockers |
|-------|---------|----------|
| 1 Performance | [...] | [N] |
| 2 Accessibility | [...] | [N] |
| 3 Motion safety | [...] | [N] |
| 4 Responsive | [...] | [N] |
| 5 Content integrity | [...] | [N] |
| 6 SEO | [...] | [N] |
| 7 Robustness | [...] | [N] |
| 8 Conversion | [...] | [N] |

Fixes applied: [list]
Blockers outstanding: [list or none]
SHIP READY: [YES / NO]

---

## Pipeline Status
Step 1 ✅ site-brief     → site_brief.md
Step 2 ✅ site-architect → site_map.md
Step 3 ✅ site-copy      → site_copy.md
Step 4 ✅ site-design    → design_system.md
Step 5 ✅ site-motion    → motion_spec.md
Step 6 ✅ site-build     → build_log.md
Step 7 ✅ site-audit     → quality_report.md
Step 8 ⬜ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `quality_report.md`, present this EXACTLY:

```
✅ Audit complete. Saved to quality_report.md.

📋 Eight checks:
  1 Performance       : [PASS / FAIL — N blockers]
  2 Accessibility     : [PASS / FAIL — N blockers]
  3 Motion safety     : [PASS / FAIL — N blockers]
  4 Responsive        : [PASS / FAIL — N blockers]
  5 Content integrity : [PASS / FAIL — N blockers]
  6 SEO and crawl     : [PASS / FAIL — N blockers]
  7 Robustness        : [PASS / FAIL — N blockers]
  8 Conversion        : [PASS / FAIL — N blockers]

Core Web Vitals (mobile, median of 3):
  LCP [N]s / 2.5s · INP [N]ms / 200ms · CLS [N] / 0.1 · Lighthouse [N] / 90

Motion safety:
  Reduced-motion fallbacks verified : [N]/[N]
  Pause controls on auto-motion     : [N]/[N]

Content:
  Placeholders : [N] (must be 0)
  Untraced claims : [N] (must be 0)
  Broken links : [N]

[IF blockers] 🛑 SHIP BLOCKED. [N] blockers:
  - [blocker, where, and the fix]
[IF a motion blocker] Motion that cannot be disabled is the one defect here
that can physically harm a visitor. That effect gets cut if it cannot be
fixed.
[IF a tier-4 perf blocker] The [effect] breaks LCP at [N]s. Lazy-loading
first; if that does not clear it, the effect is cut. The gate does not move.

[IF clean] ✅ SHIP READY. All eight checks pass.

👉 Review quality_report.md. You can:
  - Approve → say "approved" or "ship it"
  - Fix a blocker → say "fix [blocker]"
  - Re-run one check → say "re-run check [N]"
  - Cut an effect → say "drop effect [N]"
  - Back to build → say "rebuild [page]"

⏸️ Waiting for approval before Ship runs.
```

**NEVER** proceed automatically.

**NEVER** report SHIP READY with an uncontrolled animation, an untraced
claim, an uncleared logo, or a placeholder in the markup.

Approval keywords: `approved`, `ship it`, `ship`,
`proceed`, `next`, `go`, `looks good`, `audit approved`
