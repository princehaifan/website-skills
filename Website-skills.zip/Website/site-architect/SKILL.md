---
name: site-architect
description: >
  Step 2 of 8 in the Motion Site Engine Pipeline. Takes site_brief.md and
  designs the information architecture: page inventory, the section order of
  every page, the conversion spine, nav and URL structure, and the section
  library drawn from twenty studied reference sites. Assigns one heading
  grammar per page and places the interactive artefact. Saves as site_map.md.
---

# Site Architect

The brief says what is true. This step decides the order a stranger meets it in.
Section order is not taste. It is the argument, sequenced.
One primary conversion per page, one idea per section,
and every page ends in the same place: the action.
Save as `site_map.md`.

---

## The Section Library

```
DRAWN FROM TWENTY STUDIED REFERENCE SITES. THESE ARE THE PARTS.
Pick from this list; do not invent a section type without a reason.

  01 NAV            3-8 links, 1-2 CTAs. One "learn" and one "start".
                    oxylabs: Web API / Proxies / Browser / Datasets / Docs /
                    Resources / Pricing + "Talk to expert" + "Get Started"
                    Some of the best sites have no nav at all (trylatent).

  02 HERO           Headline, subhead, 1-2 CTAs, one visual.
                    The visual is a loop, a demo panel, or a product shot.
                    Never a stock illustration.

  03 PROOF BAR      Immediately after the hero. Logo wall, client count, or
                    a stat row. oxylabs runs a logo bar directly under the
                    hero; lovable runs the logo wall lower but leads with
                    aggregate counts.

  04 CAPABILITY     3-8 sections, one idea each. This is the body of the page.
                    See the heading grammars below.

  05 INTERACTIVE    The artefact from Round 7. A thing the visitor operates.
     ARTEFACT       This is the section that makes the site memorable.

  06 SIMULATED      The product's OUTPUT shown as UI, not described.
     OUTPUT         bops.bot is built almost entirely from this: an approval
                    card with Approve / Not now, a "Done today" activity
                    feed, a staff ID card, sample text/email/call exchanges.
                    Extremely high-conversion. Use where the product's value
                    is visible in its output.

  07 NUMBERED       01 / 02 / 03 panels. trylatent: 01 Record, 02 Track,
     SEQUENCE       03 Share. Natural fit for scroll-pinned choreography.

  08 EDITORIAL      A rhythm break mid-page. oryzo runs a satirical magazine
     BREAK          spread ("ISSUE NO. 00124"). Advanced; use once at most.

  09 TESTIMONIALS   Named, with role and company. Video if you have it.

  10 CASE STUDIES   Cards carrying an outcome metric each. lovable's four
                    cards each lead with a number and a "Read [company]" CTA.

  11 TRUST STACK    B2B only. Certifications, awards, insurance, trust
                    centre. oxylabs: ISO/IEC 27001:2022, SOC 2 Type II,
                    PCMag Editors' Choice, GDPR and EU AI Act alignment.

  12 SHIPPING FEED  A public changelog or release-notes stream. oxylabs
                    calls it "Always shipping". Cheap credibility that
                    compounds, and it gives the blog shell a reason to exist.

  13 AGGREGATE      One section of pure scale. lovable: 1.2M projects
     STATS          weekly, 60M total, 900M monthly visits.

  14 PRICING        Tiers or usage-based. bops publishes per-unit rates
                    openly ($0/month base, hourly compute, $3/month number).

  15 FAQ            Answers the arrival objection from Round 2.
                    trylatent's covers pricing, camera use, privacy,
                    platform availability — the real questions.

  16 CLOSING CTA    A full section, not a button in the footer.
                    oxylabs: "Give agents the live web."

  17 FOOTER         Nav, legal, social, contact, newsletter.

SECTION COUNT BUDGET:
  Home        8-12 sections
  Feature     6-9
  Pricing     4-6 (tiers, comparison, FAQ, CTA)
  About       4-6
  Docs/Blog   template, not a section list
  □ Over 12 on any page → cut or split. Length is not depth.
```

---

## The Five Heading Grammars

```
PICK ONE PER PAGE AND HOLD IT. MIXING THEM IS THE FASTEST WAY TO LOOK
INCOHERENT. These are the five observed across the reference set.

  G1 NOUN, PAST-PARTICIPLE
     "Hosting, handled." · "Payments, processed." · "Safe and secure, as
     standard."                                            (lovable.dev)
     Calm, confident, enterprise. Scales to many sections without fatigue.

  G2 NUMBERED PANEL
     "01 Record" · "02 Track" · "03 Share"                 (trylatent.co)
     Best where the product is a sequence. Pairs with scroll-pinning.

  G3 DECLARATIVE CLAIM
     "The whole web, one API call away." · "Enterprise-grade by default."
     · "Native for agents — open for everything else."        (oxylabs.io)
     Each heading is the section's argument in one line. Most work to
     write, highest payoff.

  G4 NEGATION / CONTRAST
     "Hire a bot, not a chatbot." · "Ops, not brunch."         (bops.bot)
     Sharp, opinionated, memorable. Needs a real competitor to push against.

  G5 PLAYFUL ABSURD
     "isn't just a coaster." · "So portable, it's wearable"    (oryzo.ai)
     Only works with Tier 3-4 motion and a product confident enough to
     joke. Fails badly on a serious B2B product.

  SELECTION RULE:
  □ Match the grammar to Round 5's tone and Round 1's stage
  □ G1 or G3 for anything selling to a business
  □ G2 where the product has an inherent order
  □ G4 where Round 1 named a specific incumbent to attack
  □ G5 only at motion tier 3+, and never on a pricing or trust page
  □ Record the chosen grammar in site_map.md — Step 3 writes to it
```

---

## Step 1 — Page Inventory

```
TAKE THE PAGE LIST FROM ROUND 6. FOR EACH PAGE, DECIDE FOUR THINGS:

  | Page | URL | Primary job | Secondary | Sections | Grammar |
  |------|-----|-------------|-----------|----------|---------|
  | Home | /   | [action]    | [action]  | [N]      | G1      |

  EVERY PAGE NEEDS:
  □ One primary job — the same as the site's, or a step toward it
  □ A secondary action for visitors not ready
  □ A section list drawn from the library
  □ One heading grammar

URL RULES:
  □ Lowercase, hyphenated, no trailing slash inconsistency
  □ No dates in evergreen URLs
  □ /pricing not /our-pricing · /docs not /documentation
  □ Decide now whether /features is one page or several — splitting later
    costs redirects
  □ Reserve /blog or /changelog even if it ships empty, so the IA does not
    need rework

THE ORPHAN CHECK:
  □ Every page reachable from the nav or from a body link on another page
  □ No page reachable only from the footer except legal and utility
  □ Every page links onward to at least one other page
```

---

## Step 2 — The Conversion Spine

```
A VISITOR SHOULD BE ABLE TO CONVERT AT ANY SCROLL DEPTH. MAP WHERE.

  CTA PLACEMENT ON THE HOME PAGE:
    Nav           — persistent, primary CTA
    Hero          — primary + secondary
    After section 3-4 — inline primary, mid-scroll
    After proof   — primary, while credibility is fresh
    Pricing       — primary per tier
    Closing       — primary, full-width section
    Footer        — tertiary (newsletter, docs, repo)

  □ Primary CTA label is IDENTICAL everywhere it appears. Varying it
    ("Get started" / "Try it free" / "Sign up") reads as three different
    offers and splits the decision.
  □ Secondary CTA is visually subordinate — never two equal buttons
  □ Never two primary CTAs in one viewport

THE SCROLL-DEPTH ARGUMENT:
  Write what a visitor knows at each depth. If they cannot convert on what
  they know, the order is wrong.
    At the hero       they know: [...]  → can they convert? [Y/N]
    After section 2   they know: [...]  → [Y/N]
    After the proof   they know: [...]  → [Y/N]
    At pricing        they know: [...]  → [Y/N]
  □ The first YES should arrive by section 3. If it arrives at pricing,
    the page is back-loaded and the top needs the proof moved up.

THE OBJECTION MAP:
  Round 2 named the arrival objection. Name the section that answers it,
  and how far down the page it sits.
    Objection: [...]  → answered by [section] at depth [N] of [N]
  □ If the objection is answered below the halfway point, move it up.
```

---

## Step 3 — Placing the Interactive Artefact

```
ROUND 7 CHOSE THE ARTEFACT. THIS STEP DECIDES WHERE IT SITS.

  PLACEMENT OPTIONS, BEST FIRST:
  1. IN THE HERO — the artefact IS the hero visual. Strongest choice when
     the product is demonstrable in one interaction. oxylabs puts a
     /Search–/Scrape toggle with a live demo panel in the hero.
  2. SECTION 2 — directly after the hero, as the first thing below the
     fold. Works when the hero needs to state the claim first.
  3. MID-PAGE — as the rhythm break, where an editorial section would go.
  4. BEFORE PRICING — as the last push, letting someone try before paying.

  □ Exactly one artefact per page. Two competing toys split attention.
  □ The artefact must work without JavaScript to the extent of showing a
    static, meaningful fallback — Step 6 enforces this
  □ It must not be the LCP element unless it renders server-side

  RECORD:
    Artefact: [...]
    Page: [...] · Placement: [option N] · Section position: [N of N]
    Static fallback: [what shows without JS]
    Keyboard path: [how someone operates it without a mouse]
```

---

## Step 4 — Nav Design

```
NAV IS AN ARCHITECTURE DECISION, NOT A COMPONENT CHOICE.

  THREE SHAPES THAT WORK:
  A MINIMAL      Logo + 2-4 links + 1 CTA. Best for a single-product site
                 with a short page list. (oryzo: Intro / Features / Product
                 / Contact)
  B PRODUCT-LED  Logo + product links + resources + pricing + 2 CTAs. For
                 multi-product B2B. (oxylabs)
  C NONE         Logo only, everything in the scroll and the footer. For a
                 one-product app site where the page IS the pitch.
                 (trylatent has no top nav at all)

  □ Pick by page count: ≤4 pages → A or C · 5-8 → A or B · 9+ → B
  □ Mobile: a drawer, with the primary CTA visible OUTSIDE the drawer
  □ Sticky or not? Sticky if the page is long and the CTA matters more than
    the 60px. State the choice.
  □ Dropdowns only at 9+ pages. Below that they hide things for no reason.

  RECORD:
    Shape: [A/B/C] · Links: [list] · CTAs: [primary, secondary]
    Sticky: [yes/no] · Mobile pattern: [...]
```

---

## Step 5 — Section-by-Section Plan

```
FOR EVERY PAGE, WRITE THE FULL SECTION LIST. THIS IS WHAT STEP 3 WRITES TO
AND STEP 5 CHOREOGRAPHS.

  PER SECTION, FOUR FIELDS:
    #  | Library type | The one idea | Motion note | Proof used
    1  | 02 HERO      | [...]        | [...]       | —
    2  | 03 PROOF BAR | [...]        | [...]       | [N] logos

  □ "The one idea" is one sentence. A section needing two sentences is two
    sections.
  □ "Motion note" is a hint for Step 5, not a spec — one phrase
  □ "Proof used" draws only on Round 4's USABLE items. Running out of proof
    mid-page means cutting a section, not inventing a claim.

  THE RHYTHM RULE:
  Never three consecutive sections of the same library type. Alternate
  text-led, visual-led and interactive. Reading five capability blocks in a
  row is where visitors leave.
  □ Check the sequence for runs of three: [list any]

  THE DELIVERY CHECK:
  Read the hero's claim, then the section list. Does the page deliver what
  the hero promised?
  □ YES → done · NO → reorder, or change the hero claim in Step 3
```

---

## Output File: site_map.md

```markdown
# Site Map
Pipeline step: 2 of 8
Date: [date]
Reads: site_brief.md

---

## Page Inventory

| Page | URL | Primary job | Secondary | Sections | Grammar |
|------|-----|-------------|-----------|----------|---------|

Pages: [N] · Orphan check: [PASS/FAIL]

---

## Heading Grammar
Chosen: [G1-G5] — [name]
Why: [one line tying it to Round 5's tone]
Applies to: [all pages / per-page exceptions listed]

---

## Conversion Spine

Primary CTA label (identical everywhere): "[label]"
Secondary CTA label: "[label]"

Placements: [list with scroll depth]

Scroll-depth argument:
| Depth | What they know | Can convert? |
|-------|----------------|--------------|

First YES at: section [N] of [N]
Objection "[...]" answered by [section] at depth [N]

---

## Interactive Artefact
Artefact: [...] · Page: [...] · Placement: [option N]
Static fallback: [...] · Keyboard path: [...]

---

## Nav
Shape: [A/B/C] · Links: [...] · CTAs: [...]
Sticky: [...] · Mobile: [...]

---

## Section Plans

### Home
| # | Library type | The one idea | Motion note | Proof used |
|---|--------------|--------------|-------------|------------|

Sections: [N] · Runs of three: [none / list]
Delivery check: [PASS/FAIL]

### [Next page]
[...]

---

## Pipeline Status
Step 1 ✅ site-brief     → site_brief.md
Step 2 ✅ site-architect → site_map.md
Step 3 ⬜ site-copy      → site_copy.md
Step 4 ⬜ site-design    → design_system.md
Step 5 ⬜ site-motion    → motion_spec.md
Step 6 ⬜ site-build     → build_log.md
Step 7 ⬜ site-audit     → quality_report.md
Step 8 ⬜ site-ship      → publish_log.md
```

---

## Review Gate (MANDATORY)

After saving `site_map.md`, present this EXACTLY:

```
✅ Architecture complete. Saved to site_map.md.

📋 Summary:
- Pages        : [N] — [list]
- Grammar      : [G[N]] [name]
- Nav          : shape [A/B/C], [N] links, [N] CTAs
- Primary CTA  : "[label]" in [N] placements
- Home         : [N] sections
- Artefact     : [the thing] in the [placement]

Conversion spine:
  First point a visitor could convert: section [N] of [N]
  Arrival objection answered at depth [N] of [N]

Checks:
  Orphan pages      : [PASS / FAIL — list]
  Runs of 3 same type: [none / list]
  Proof sufficient   : [N] usable items across [N] sections [PASS/FAIL]
  Delivery check     : [PASS/FAIL per page]

[IF proof insufficient] ⚠️ [N] sections planned need proof and only [N]
usable items exist. Cutting [section] rather than inventing a claim.

[IF first YES is late] ⚠️ A visitor cannot convert until section [N]. The
page is back-loaded — recommend moving [section] above [section].

👉 Review site_map.md. You can:
  - Approve → say "approved" or "write the copy"
  - Reorder → say "move [section] before [section]"
  - Change grammar → say "use G[N]"
  - Cut a section → say "drop [section]"
  - Move the artefact → say "put the demo in the hero"
  - Change nav → say "nav shape [A/B/C]"

⏸️ Waiting for approval before Copy runs.
```

**NEVER** proceed automatically.

**NEVER** plan a section whose proof does not exist in Round 4's usable list.

Approval keywords: `approved`, `write the copy`, `copy`,
`proceed`, `next`, `go`, `looks good`, `map approved`
